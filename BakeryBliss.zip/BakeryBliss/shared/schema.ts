import { pgTable, text, serial, integer, json, boolean, timestamp, uniqueIndex } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name"),
  email: text("email"),
  bio: text("bio"),
  avatarUrl: text("avatar_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User profiles
export const userProfiles = pgTable("user_profiles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull().unique(),
  favoriteFlavors: json("favorite_flavors").default([]),
  bakingLevel: text("baking_level").default("beginner"), // beginner, intermediate, advanced
  achievements: json("achievements").default([]),
  bakingStreak: integer("baking_streak").default(0),
  lastActive: timestamp("last_active").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Ingredient model
export const ingredients = pgTable("ingredients", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(), // "base", "flavor", "mix-in"
  imageUrl: text("image_url"),
  available: boolean("available").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Frosting model
export const frostings = pgTable("frostings", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  color: text("color").notNull(),
  imageUrl: text("image_url"),
  available: boolean("available").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Decoration model
export const decorations = pgTable("decorations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(), // "sprinkles", "fruit", "chocolate", "candy"
  imageUrl: text("image_url"),
  available: boolean("available").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Recipe model
export const recipes = pgTable("recipes", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // "cake", "cookie", "pastry", "brownie"
  description: text("description").notNull(),
  ingredients: json("ingredients").notNull(),
  steps: json("steps").notNull(),
  prepTime: integer("prep_time").notNull(),
  imageUrl: text("image_url"),
  rating: integer("rating").default(5),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  isThemed: boolean("is_themed").default(false),
  memoryTags: json("memory_tags").default([]),
});

// BakedItem model
export const bakedItems = pgTable("baked_items", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  recipeId: integer("recipe_id").references(() => recipes.id),
  name: text("name").notNull(),
  type: text("type").notNull(), // "cake", "cookie", "pastry", "brownie"
  ingredients: json("ingredients").notNull(),
  frosting: text("frosting"),
  decoration: json("decoration"),
  customMessage: text("custom_message"),
  imageUrl: text("image_url"),
  isPublic: boolean("is_public").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Favorites model for user profiles
export const favorites = pgTable("favorites", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  bakedItemId: integer("baked_item_id").references(() => bakedItems.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
}, (t) => ({
  userItemIndex: uniqueIndex("user_item_idx").on(t.userId, t.bakedItemId),
}));

// Themed events based on childhood memories
export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  theme: text("theme").notNull(), // e.g., "birthday", "holiday", "school days"
  memoryDescription: text("memory_description").notNull(),
  imageUrl: text("image_url"),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Event participants
export const eventParticipants = pgTable("event_participants", {
  id: serial("id").primaryKey(),
  eventId: integer("event_id").references(() => events.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  submissionId: integer("submission_id").references(() => bakedItems.id),
  memoryStory: text("memory_story"),
  joinedAt: timestamp("joined_at").defaultNow(),
}, (t) => ({
  eventUserIndex: uniqueIndex("event_user_idx").on(t.eventId, t.userId),
}));

// Event recipes
export const eventRecipes = pgTable("event_recipes", {
  id: serial("id").primaryKey(),
  eventId: integer("event_id").references(() => events.id).notNull(),
  recipeId: integer("recipe_id").references(() => recipes.id).notNull(),
  isFeatured: boolean("is_featured").default(false),
  addedAt: timestamp("added_at").defaultNow(),
}, (t) => ({
  eventRecipeIndex: uniqueIndex("event_recipe_idx").on(t.eventId, t.recipeId),
}));

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  bakedItems: many(bakedItems),
  favorites: many(favorites),
  eventParticipations: many(eventParticipants),
  userProfiles: many(userProfiles),
}));

export const userProfilesRelations = relations(userProfiles, ({ one }) => ({
  user: one(users, {
    fields: [userProfiles.userId],
    references: [users.id],
  }),
}));

export const bakedItemsRelations = relations(bakedItems, ({ one, many }) => ({
  user: one(users, {
    fields: [bakedItems.userId],
    references: [users.id],
  }),
  recipe: one(recipes, {
    fields: [bakedItems.recipeId],
    references: [recipes.id],
  }),
  favorites: many(favorites),
}));

export const favoritesRelations = relations(favorites, ({ one }) => ({
  user: one(users, {
    fields: [favorites.userId],
    references: [users.id],
  }),
  bakedItem: one(bakedItems, {
    fields: [favorites.bakedItemId],
    references: [bakedItems.id],
  }),
}));

export const eventsRelations = relations(events, ({ many }) => ({
  participants: many(eventParticipants),
  featuredRecipes: many(eventRecipes),
}));

export const eventParticipantsRelations = relations(eventParticipants, ({ one }) => ({
  event: one(events, {
    fields: [eventParticipants.eventId],
    references: [events.id],
  }),
  user: one(users, {
    fields: [eventParticipants.userId],
    references: [users.id],
  }),
  submission: one(bakedItems, {
    fields: [eventParticipants.submissionId],
    references: [bakedItems.id],
  }),
}));

export const recipesRelations = relations(recipes, ({ many }) => ({
  bakedItems: many(bakedItems),
  events: many(eventRecipes),
}));

export const eventRecipesRelations = relations(eventRecipes, ({ one }) => ({
  event: one(events, {
    fields: [eventRecipes.eventId],
    references: [events.id],
  }),
  recipe: one(recipes, {
    fields: [eventRecipes.recipeId],
    references: [recipes.id],
  }),
}));

// Schemas for insertion
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  email: true,
  bio: true,
  avatarUrl: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const insertUserProfileSchema = createInsertSchema(userProfiles).omit({
  id: true,
  updatedAt: true,
});

export type InsertUserProfile = z.infer<typeof insertUserProfileSchema>;
export type UserProfile = typeof userProfiles.$inferSelect;

export const insertBakedItemSchema = createInsertSchema(bakedItems).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertBakedItem = z.infer<typeof insertBakedItemSchema>;
export type BakedItem = typeof bakedItems.$inferSelect;

export const insertFavoriteSchema = createInsertSchema(favorites).omit({
  id: true,
  createdAt: true,
});

export type InsertFavorite = z.infer<typeof insertFavoriteSchema>;
export type Favorite = typeof favorites.$inferSelect;

export const insertEventSchema = createInsertSchema(events).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertEvent = z.infer<typeof insertEventSchema>;
export type Event = typeof events.$inferSelect;

export const insertEventParticipantSchema = createInsertSchema(eventParticipants).omit({
  id: true,
  joinedAt: true,
});

export type InsertEventParticipant = z.infer<typeof insertEventParticipantSchema>;
export type EventParticipant = typeof eventParticipants.$inferSelect;

export const insertEventRecipeSchema = createInsertSchema(eventRecipes).omit({
  id: true,
  addedAt: true,
});

export type InsertEventRecipe = z.infer<typeof insertEventRecipeSchema>;
export type EventRecipe = typeof eventRecipes.$inferSelect;

export const insertIngredientSchema = createInsertSchema(ingredients).omit({
  id: true,
  createdAt: true,
});

export type InsertIngredient = z.infer<typeof insertIngredientSchema>;
export type Ingredient = typeof ingredients.$inferSelect;

export const insertFrostingSchema = createInsertSchema(frostings).omit({
  id: true,
  createdAt: true,
});

export type InsertFrosting = z.infer<typeof insertFrostingSchema>;
export type Frosting = typeof frostings.$inferSelect;

export const insertDecorationSchema = createInsertSchema(decorations).omit({
  id: true,
  createdAt: true,
});

export type InsertDecoration = z.infer<typeof insertDecorationSchema>;
export type Decoration = typeof decorations.$inferSelect;

export const insertRecipeSchema = createInsertSchema(recipes).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertRecipe = z.infer<typeof insertRecipeSchema>;
export type Recipe = typeof recipes.$inferSelect;