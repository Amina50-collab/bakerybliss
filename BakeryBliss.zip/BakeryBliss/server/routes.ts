import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { 
  insertBakedItemSchema, 
  insertUserProfileSchema, 
  insertFavoriteSchema,
  insertEventSchema,
  insertEventParticipantSchema,
  insertEventRecipeSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // prefix all routes with /api
  
  // Get all ingredients
  app.get("/api/ingredients", async (req, res) => {
    try {
      const ingredients = await storage.getAllIngredients();
      res.json(ingredients);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch ingredients" });
    }
  });
  
  // Get ingredients by category
  app.get("/api/ingredients/category/:category", async (req, res) => {
    try {
      const { category } = req.params;
      const ingredients = await storage.getIngredientsByCategory(category);
      res.json(ingredients);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch ingredients by category" });
    }
  });
  
  // Get all frostings
  app.get("/api/frostings", async (req, res) => {
    try {
      const frostings = await storage.getAllFrostings();
      res.json(frostings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch frostings" });
    }
  });
  
  // Get all decorations
  app.get("/api/decorations", async (req, res) => {
    try {
      const decorations = await storage.getAllDecorations();
      res.json(decorations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch decorations" });
    }
  });
  
  // Get decorations by category
  app.get("/api/decorations/category/:category", async (req, res) => {
    try {
      const { category } = req.params;
      const decorations = await storage.getDecorationsByCategory(category);
      res.json(decorations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch decorations by category" });
    }
  });
  
  // Get all recipes
  app.get("/api/recipes", async (req, res) => {
    try {
      const recipes = await storage.getAllRecipes();
      res.json(recipes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recipes" });
    }
  });
  
  // Get recipes by type
  app.get("/api/recipes/type/:type", async (req, res) => {
    try {
      const { type } = req.params;
      const recipes = await storage.getRecipesByType(type);
      res.json(recipes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recipes by type" });
    }
  });
  
  // Get themed recipes
  app.get("/api/recipes/themed", async (req, res) => {
    try {
      const recipes = await storage.getThemedRecipes();
      res.json(recipes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch themed recipes" });
    }
  });
  
  // Get recipe by id
  app.get("/api/recipes/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid recipe ID" });
      }
      
      const recipe = await storage.getRecipe(id);
      if (!recipe) {
        return res.status(404).json({ message: "Recipe not found" });
      }
      
      res.json(recipe);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recipe" });
    }
  });
  
  // Create a baked item
  app.post("/api/baked-items", async (req, res) => {
    try {
      const validation = insertBakedItemSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid baked item data", errors: validation.error.errors });
      }
      
      const bakedItem = await storage.createBakedItem(validation.data);
      res.status(201).json(bakedItem);
    } catch (error) {
      res.status(500).json({ message: "Failed to create baked item" });
    }
  });
  
  // Get all baked items
  app.get("/api/baked-items", async (req, res) => {
    try {
      const bakedItems = await storage.getAllBakedItems();
      res.json(bakedItems);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch baked items" });
    }
  });
  
  // Get public baked items
  app.get("/api/baked-items/public", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const bakedItems = await storage.getPublicBakedItems(limit);
      res.json(bakedItems);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch public baked items" });
    }
  });
  
  // Get baked items by user ID
  app.get("/api/users/:userId/baked-items", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const bakedItems = await storage.getBakedItemsByUserId(userId);
      res.json(bakedItems);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user's baked items" });
    }
  });
  
  // Get baked item by id
  app.get("/api/baked-items/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid baked item ID" });
      }
      
      const bakedItem = await storage.getBakedItem(id);
      if (!bakedItem) {
        return res.status(404).json({ message: "Baked item not found" });
      }
      
      res.json(bakedItem);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch baked item" });
    }
  });
  
  // Update a baked item
  app.patch("/api/baked-items/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid baked item ID" });
      }
      
      const bakedItem = await storage.getBakedItem(id);
      if (!bakedItem) {
        return res.status(404).json({ message: "Baked item not found" });
      }
      
      const updatedItem = await storage.updateBakedItem(id, req.body);
      res.json(updatedItem);
    } catch (error) {
      res.status(500).json({ message: "Failed to update baked item" });
    }
  });
  
  // Delete a baked item
  app.delete("/api/baked-items/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid baked item ID" });
      }
      
      const deleted = await storage.deleteBakedItem(id);
      if (!deleted) {
        return res.status(404).json({ message: "Baked item not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete baked item" });
    }
  });
  
  // USER PROFILE ROUTES
  
  // Get user profile
  app.get("/api/users/:userId/profile", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const profile = await storage.getUserProfile(userId);
      if (!profile) {
        return res.status(404).json({ message: "User profile not found" });
      }
      
      res.json(profile);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user profile" });
    }
  });
  
  // Create user profile
  app.post("/api/users/:userId/profile", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      // Check if user exists
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Check if profile already exists
      const existingProfile = await storage.getUserProfile(userId);
      if (existingProfile) {
        return res.status(409).json({ message: "User profile already exists" });
      }
      
      // Validate and create profile
      const profileData = { ...req.body, userId };
      const validation = insertUserProfileSchema.safeParse(profileData);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid profile data", errors: validation.error.errors });
      }
      
      const profile = await storage.createUserProfile(validation.data);
      res.status(201).json(profile);
    } catch (error) {
      res.status(500).json({ message: "Failed to create user profile" });
    }
  });
  
  // Update user profile
  app.patch("/api/users/:userId/profile", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      // Check if profile exists
      const existingProfile = await storage.getUserProfile(userId);
      if (!existingProfile) {
        return res.status(404).json({ message: "User profile not found" });
      }
      
      const updatedProfile = await storage.updateUserProfile(userId, req.body);
      res.json(updatedProfile);
    } catch (error) {
      res.status(500).json({ message: "Failed to update user profile" });
    }
  });
  
  // FAVORITES ROUTES
  
  // Get user favorites
  app.get("/api/users/:userId/favorites", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const favorites = await storage.getUserFavorites(userId);
      res.json(favorites);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user favorites" });
    }
  });
  
  // Add to favorites
  app.post("/api/users/:userId/favorites", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const favoriteData = { ...req.body, userId };
      const validation = insertFavoriteSchema.safeParse(favoriteData);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid favorite data", errors: validation.error.errors });
      }
      
      // Check if user and baked item exist
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const bakedItem = await storage.getBakedItem(validation.data.bakedItemId);
      if (!bakedItem) {
        return res.status(404).json({ message: "Baked item not found" });
      }
      
      // Check if already a favorite
      const isAlreadyFavorite = await storage.isFavorite(userId, validation.data.bakedItemId);
      if (isAlreadyFavorite) {
        return res.status(409).json({ message: "Already added to favorites" });
      }
      
      const favorite = await storage.addFavorite(validation.data);
      res.status(201).json(favorite);
    } catch (error) {
      res.status(500).json({ message: "Failed to add to favorites" });
    }
  });
  
  // Remove from favorites
  app.delete("/api/users/:userId/favorites/:bakedItemId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const bakedItemId = parseInt(req.params.bakedItemId);
      
      if (isNaN(userId) || isNaN(bakedItemId)) {
        return res.status(400).json({ message: "Invalid ID parameters" });
      }
      
      // Check if it's a favorite
      const isFavorite = await storage.isFavorite(userId, bakedItemId);
      if (!isFavorite) {
        return res.status(404).json({ message: "Favorite not found" });
      }
      
      const removed = await storage.removeFavorite(userId, bakedItemId);
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Failed to remove from favorites" });
    }
  });
  
  // Check if item is favorited
  app.get("/api/users/:userId/favorites/:bakedItemId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const bakedItemId = parseInt(req.params.bakedItemId);
      
      if (isNaN(userId) || isNaN(bakedItemId)) {
        return res.status(400).json({ message: "Invalid ID parameters" });
      }
      
      const isFavorite = await storage.isFavorite(userId, bakedItemId);
      res.json({ isFavorite });
    } catch (error) {
      res.status(500).json({ message: "Failed to check favorite status" });
    }
  });
  
  // THEMED EVENTS ROUTES
  
  // Get all events
  app.get("/api/events", async (req, res) => {
    try {
      const events = await storage.getAllEvents();
      res.json(events);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch events" });
    }
  });
  
  // Get active events
  app.get("/api/events/active", async (req, res) => {
    try {
      const events = await storage.getActiveEvents();
      res.json(events);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch active events" });
    }
  });
  
  // Get event by ID
  app.get("/api/events/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid event ID" });
      }
      
      const event = await storage.getEvent(id);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      res.json(event);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch event" });
    }
  });
  
  // Create a new event
  app.post("/api/events", async (req, res) => {
    try {
      const validation = insertEventSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid event data", errors: validation.error.errors });
      }
      
      const event = await storage.createEvent(validation.data);
      res.status(201).json(event);
    } catch (error) {
      res.status(500).json({ message: "Failed to create event" });
    }
  });
  
  // Update an event
  app.patch("/api/events/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid event ID" });
      }
      
      const event = await storage.getEvent(id);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      const updatedEvent = await storage.updateEvent(id, req.body);
      res.json(updatedEvent);
    } catch (error) {
      res.status(500).json({ message: "Failed to update event" });
    }
  });
  
  // Get event participants
  app.get("/api/events/:id/participants", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid event ID" });
      }
      
      const participants = await storage.getEventParticipants(id);
      res.json(participants);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch event participants" });
    }
  });
  
  // Join an event
  app.post("/api/events/:id/participants", async (req, res) => {
    try {
      const eventId = parseInt(req.params.id);
      if (isNaN(eventId)) {
        return res.status(400).json({ message: "Invalid event ID" });
      }
      
      // Check if event exists
      const event = await storage.getEvent(eventId);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      const participationData = { ...req.body, eventId };
      const validation = insertEventParticipantSchema.safeParse(participationData);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid participation data", errors: validation.error.errors });
      }
      
      // Check if user exists
      const user = await storage.getUser(validation.data.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const participant = await storage.joinEvent(validation.data);
      res.status(201).json(participant);
    } catch (error) {
      res.status(500).json({ message: "Failed to join event" });
    }
  });
  
  // Leave an event
  app.delete("/api/events/:eventId/participants/:userId", async (req, res) => {
    try {
      const eventId = parseInt(req.params.eventId);
      const userId = parseInt(req.params.userId);
      
      if (isNaN(eventId) || isNaN(userId)) {
        return res.status(400).json({ message: "Invalid ID parameters" });
      }
      
      const left = await storage.leaveEvent(userId, eventId);
      if (!left) {
        return res.status(404).json({ message: "Participation not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Failed to leave event" });
    }
  });
  
  // Get event recipes
  app.get("/api/events/:id/recipes", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid event ID" });
      }
      
      const recipes = await storage.getEventRecipes(id);
      res.json(recipes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch event recipes" });
    }
  });
  
  // Add recipe to event
  app.post("/api/events/:id/recipes", async (req, res) => {
    try {
      const eventId = parseInt(req.params.id);
      if (isNaN(eventId)) {
        return res.status(400).json({ message: "Invalid event ID" });
      }
      
      // Check if event exists
      const event = await storage.getEvent(eventId);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      const eventRecipeData = { ...req.body, eventId };
      const validation = insertEventRecipeSchema.safeParse(eventRecipeData);
      if (!validation.success) {
        return res.status(400).json({ message: "Invalid event recipe data", errors: validation.error.errors });
      }
      
      // Check if recipe exists
      const recipe = await storage.getRecipe(validation.data.recipeId);
      if (!recipe) {
        return res.status(404).json({ message: "Recipe not found" });
      }
      
      const eventRecipe = await storage.addRecipeToEvent(validation.data);
      res.status(201).json(eventRecipe);
    } catch (error) {
      res.status(500).json({ message: "Failed to add recipe to event" });
    }
  });
  
  // Remove recipe from event
  app.delete("/api/events/:eventId/recipes/:recipeId", async (req, res) => {
    try {
      const eventId = parseInt(req.params.eventId);
      const recipeId = parseInt(req.params.recipeId);
      
      if (isNaN(eventId) || isNaN(recipeId)) {
        return res.status(400).json({ message: "Invalid ID parameters" });
      }
      
      const removed = await storage.removeRecipeFromEvent(eventId, recipeId);
      if (!removed) {
        return res.status(404).json({ message: "Event recipe not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Failed to remove recipe from event" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
