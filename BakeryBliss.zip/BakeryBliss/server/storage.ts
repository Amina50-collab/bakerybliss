import { 
  users, type User, type InsertUser,
  bakedItems, type BakedItem, type InsertBakedItem,
  ingredients, type Ingredient, type InsertIngredient,
  frostings, type Frosting, type InsertFrosting,
  decorations, type Decoration, type InsertDecoration,
  recipes, type Recipe, type InsertRecipe,
  userProfiles, type UserProfile, type InsertUserProfile,
  favorites, type Favorite, type InsertFavorite,
  events, type Event, type InsertEvent,
  eventParticipants, type EventParticipant, type InsertEventParticipant,
  eventRecipes, type EventRecipe, type InsertEventRecipe
} from "@shared/schema";
import { eq, desc, and, gte, lte } from "drizzle-orm";
import { db } from "./db";

// Storage interface for CRUD operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined>;
  
  // User Profile operations
  getUserProfile(userId: number): Promise<UserProfile | undefined>;
  createUserProfile(profile: InsertUserProfile): Promise<UserProfile>;
  updateUserProfile(userId: number, profileData: Partial<InsertUserProfile>): Promise<UserProfile | undefined>;
  
  // BakedItem operations
  getAllBakedItems(): Promise<BakedItem[]>;
  getBakedItemsByUserId(userId: number): Promise<BakedItem[]>;
  getPublicBakedItems(limit?: number): Promise<BakedItem[]>;
  getBakedItem(id: number): Promise<BakedItem | undefined>;
  createBakedItem(item: InsertBakedItem): Promise<BakedItem>;
  updateBakedItem(id: number, itemData: Partial<InsertBakedItem>): Promise<BakedItem | undefined>;
  deleteBakedItem(id: number): Promise<boolean>;
  
  // Favorites operations
  getUserFavorites(userId: number): Promise<BakedItem[]>;
  addFavorite(favorite: InsertFavorite): Promise<Favorite>;
  removeFavorite(userId: number, bakedItemId: number): Promise<boolean>;
  isFavorite(userId: number, bakedItemId: number): Promise<boolean>;
  
  // Themed Events operations
  getAllEvents(): Promise<Event[]>;
  getActiveEvents(): Promise<Event[]>; 
  getEvent(id: number): Promise<Event | undefined>;
  createEvent(event: InsertEvent): Promise<Event>;
  updateEvent(id: number, eventData: Partial<InsertEvent>): Promise<Event | undefined>;
  getEventParticipants(eventId: number): Promise<EventParticipant[]>;
  joinEvent(participation: InsertEventParticipant): Promise<EventParticipant>;
  leaveEvent(userId: number, eventId: number): Promise<boolean>;
  getEventRecipes(eventId: number): Promise<Recipe[]>;
  addRecipeToEvent(eventRecipe: InsertEventRecipe): Promise<EventRecipe>;
  removeRecipeFromEvent(eventId: number, recipeId: number): Promise<boolean>;
  
  // Ingredient operations
  getAllIngredients(): Promise<Ingredient[]>;
  getIngredientsByCategory(category: string): Promise<Ingredient[]>;
  getIngredient(id: number): Promise<Ingredient | undefined>;
  
  // Frosting operations
  getAllFrostings(): Promise<Frosting[]>;
  getFrosting(id: number): Promise<Frosting | undefined>;
  
  // Decoration operations
  getAllDecorations(): Promise<Decoration[]>;
  getDecorationsByCategory(category: string): Promise<Decoration[]>;
  getDecoration(id: number): Promise<Decoration | undefined>;
  
  // Recipe operations
  getAllRecipes(): Promise<Recipe[]>;
  getRecipesByType(type: string): Promise<Recipe[]>;
  getThemedRecipes(): Promise<Recipe[]>;
  getRecipe(id: number): Promise<Recipe | undefined>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private userProfiles: Map<number, UserProfile>;
  private bakedItems: Map<number, BakedItem>;
  private favorites: Map<string, Favorite>;
  private ingredients: Map<number, Ingredient>;
  private frostings: Map<number, Frosting>;
  private decorations: Map<number, Decoration>;
  private recipes: Map<number, Recipe>;
  private events: Map<number, Event>;
  private eventParticipants: Map<number, EventParticipant>;
  private eventRecipes: Map<number, EventRecipe>;
  
  private userId: number = 1;
  private userProfileId: number = 1;
  private bakedItemId: number = 1;
  private favoriteId: number = 1;
  private ingredientId: number = 1;
  private frostingId: number = 1;
  private decorationId: number = 1;
  private recipeId: number = 1;
  private eventId: number = 1;
  private eventParticipantId: number = 1;
  private eventRecipeId: number = 1;

  constructor() {
    this.users = new Map();
    this.userProfiles = new Map();
    this.bakedItems = new Map();
    this.favorites = new Map();
    this.ingredients = new Map();
    this.frostings = new Map();
    this.decorations = new Map();
    this.recipes = new Map();
    this.events = new Map();
    this.eventParticipants = new Map();
    this.eventRecipes = new Map();
    
    // Populate with initial data
    this.seedData();
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id,
      name: insertUser.name || null,
      email: insertUser.email || null,
      bio: insertUser.bio || null,
      avatarUrl: insertUser.avatarUrl || null,
      createdAt: now,
      updatedAt: now
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser: User = {
      ...user,
      ...userData,
      updatedAt: new Date()
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  // User Profile operations
  async getUserProfile(userId: number): Promise<UserProfile | undefined> {
    return Array.from(this.userProfiles.values()).find(
      (profile) => profile.userId === userId
    );
  }
  
  async createUserProfile(profile: InsertUserProfile): Promise<UserProfile> {
    const id = this.userProfileId++;
    const now = new Date();
    const userProfile: UserProfile = {
      ...profile,
      id,
      favoriteFlavors: profile.favoriteFlavors || [],
      bakingLevel: profile.bakingLevel || "beginner",
      achievements: profile.achievements || [],
      bakingStreak: profile.bakingStreak || 0,
      lastActive: now,
      updatedAt: now
    };
    this.userProfiles.set(id, userProfile);
    return userProfile;
  }
  
  async updateUserProfile(userId: number, profileData: Partial<InsertUserProfile>): Promise<UserProfile | undefined> {
    const profile = Array.from(this.userProfiles.values()).find(
      (p) => p.userId === userId
    );
    
    if (!profile) return undefined;
    
    const updatedProfile: UserProfile = {
      ...profile,
      ...profileData,
      lastActive: new Date(),
      updatedAt: new Date()
    };
    
    this.userProfiles.set(profile.id, updatedProfile);
    return updatedProfile;
  }

  // BakedItem operations
  async getAllBakedItems(): Promise<BakedItem[]> {
    return Array.from(this.bakedItems.values());
  }
  
  async getBakedItemsByUserId(userId: number): Promise<BakedItem[]> {
    return Array.from(this.bakedItems.values()).filter(
      (item) => item.userId === userId
    );
  }
  
  async getPublicBakedItems(limit?: number): Promise<BakedItem[]> {
    const items = Array.from(this.bakedItems.values())
      .filter(item => item.isPublic)
      .sort((a, b) => {
        if (!a.createdAt || !b.createdAt) return 0;
        return b.createdAt.getTime() - a.createdAt.getTime();
      });
    
    return limit ? items.slice(0, limit) : items;
  }
  
  async getBakedItem(id: number): Promise<BakedItem | undefined> {
    return this.bakedItems.get(id);
  }
  
  async createBakedItem(insertItem: InsertBakedItem): Promise<BakedItem> {
    const id = this.bakedItemId++;
    const now = new Date();
    const bakedItem: BakedItem = { 
      ...insertItem, 
      id, 
      userId: insertItem.userId || null,
      recipeId: insertItem.recipeId || null,
      frosting: insertItem.frosting || null,
      decoration: insertItem.decoration || null,
      customMessage: insertItem.customMessage || null,
      imageUrl: insertItem.imageUrl || null,
      isPublic: insertItem.isPublic ?? false,
      createdAt: now,
      updatedAt: now
    };
    this.bakedItems.set(id, bakedItem);
    return bakedItem;
  }

  async updateBakedItem(id: number, itemData: Partial<InsertBakedItem>): Promise<BakedItem | undefined> {
    const item = this.bakedItems.get(id);
    if (!item) return undefined;
    
    const updatedItem: BakedItem = {
      ...item,
      ...itemData,
      updatedAt: new Date()
    };
    
    this.bakedItems.set(id, updatedItem);
    return updatedItem;
  }
  
  async deleteBakedItem(id: number): Promise<boolean> {
    return this.bakedItems.delete(id);
  }

  // Favorites operations
  async getUserFavorites(userId: number): Promise<BakedItem[]> {
    const userFavorites = Array.from(this.favorites.values())
      .filter(fav => fav.userId === userId);
    
    return userFavorites.map(fav => {
      const item = this.bakedItems.get(fav.bakedItemId);
      if (!item) throw new Error(`Baked item with id ${fav.bakedItemId} not found`);
      return item;
    });
  }
  
  async addFavorite(insertFavorite: InsertFavorite): Promise<Favorite> {
    const id = this.favoriteId++;
    const key = `${insertFavorite.userId}-${insertFavorite.bakedItemId}`;
    const now = new Date();
    
    const favorite: Favorite = {
      ...insertFavorite,
      id,
      createdAt: now
    };
    
    this.favorites.set(key, favorite);
    return favorite;
  }
  
  async removeFavorite(userId: number, bakedItemId: number): Promise<boolean> {
    const key = `${userId}-${bakedItemId}`;
    return this.favorites.delete(key);
  }
  
  async isFavorite(userId: number, bakedItemId: number): Promise<boolean> {
    const key = `${userId}-${bakedItemId}`;
    return this.favorites.has(key);
  }

  // Event operations
  async getAllEvents(): Promise<Event[]> {
    return Array.from(this.events.values()).sort((a, b) => {
      return new Date(b.startDate).getTime() - new Date(a.startDate).getTime();
    });
  }
  
  async getActiveEvents(): Promise<Event[]> {
    const now = new Date();
    return Array.from(this.events.values())
      .filter(event => 
        event.isActive && 
        new Date(event.startDate) <= now &&
        new Date(event.endDate) >= now
      )
      .sort((a, b) => {
        return new Date(b.startDate).getTime() - new Date(a.startDate).getTime();
      });
  }
  
  async getEvent(id: number): Promise<Event | undefined> {
    return this.events.get(id);
  }
  
  async createEvent(insertEvent: InsertEvent): Promise<Event> {
    const id = this.eventId++;
    const now = new Date();
    
    const event: Event = {
      ...insertEvent,
      id,
      imageUrl: insertEvent.imageUrl || null,
      isActive: insertEvent.isActive ?? true,
      createdAt: now,
      updatedAt: now
    };
    
    this.events.set(id, event);
    return event;
  }
  
  async updateEvent(id: number, eventData: Partial<InsertEvent>): Promise<Event | undefined> {
    const event = this.events.get(id);
    if (!event) return undefined;
    
    const updatedEvent: Event = {
      ...event,
      ...eventData,
      updatedAt: new Date()
    };
    
    this.events.set(id, updatedEvent);
    return updatedEvent;
  }
  
  async getEventParticipants(eventId: number): Promise<EventParticipant[]> {
    return Array.from(this.eventParticipants.values())
      .filter(p => p.eventId === eventId);
  }
  
  async joinEvent(participation: InsertEventParticipant): Promise<EventParticipant> {
    const id = this.eventParticipantId++;
    const now = new Date();
    
    const participant: EventParticipant = {
      ...participation,
      id,
      submissionId: participation.submissionId || null,
      memoryStory: participation.memoryStory || null,
      joinedAt: now
    };
    
    this.eventParticipants.set(id, participant);
    return participant;
  }
  
  async leaveEvent(userId: number, eventId: number): Promise<boolean> {
    const participant = Array.from(this.eventParticipants.values())
      .find(p => p.userId === userId && p.eventId === eventId);
    
    if (!participant) return false;
    return this.eventParticipants.delete(participant.id);
  }
  
  async getEventRecipes(eventId: number): Promise<Recipe[]> {
    const eventRecipeEntries = Array.from(this.eventRecipes.values())
      .filter(er => er.eventId === eventId);
    
    return eventRecipeEntries.map(er => {
      const recipe = this.recipes.get(er.recipeId);
      if (!recipe) throw new Error(`Recipe with id ${er.recipeId} not found`);
      return recipe;
    });
  }
  
  async addRecipeToEvent(eventRecipe: InsertEventRecipe): Promise<EventRecipe> {
    const id = this.eventRecipeId++;
    const now = new Date();
    
    const newEventRecipe: EventRecipe = {
      ...eventRecipe,
      id,
      isFeatured: eventRecipe.isFeatured ?? null,
      addedAt: now
    };
    
    this.eventRecipes.set(id, newEventRecipe);
    return newEventRecipe;
  }
  
  async removeRecipeFromEvent(eventId: number, recipeId: number): Promise<boolean> {
    const eventRecipe = Array.from(this.eventRecipes.values())
      .find(er => er.eventId === eventId && er.recipeId === recipeId);
    
    if (!eventRecipe) return false;
    return this.eventRecipes.delete(eventRecipe.id);
  }

  // Ingredient operations
  async getAllIngredients(): Promise<Ingredient[]> {
    return Array.from(this.ingredients.values());
  }
  
  async getIngredientsByCategory(category: string): Promise<Ingredient[]> {
    return Array.from(this.ingredients.values()).filter(
      (ingredient) => ingredient.category === category
    );
  }
  
  async getIngredient(id: number): Promise<Ingredient | undefined> {
    return this.ingredients.get(id);
  }

  // Frosting operations
  async getAllFrostings(): Promise<Frosting[]> {
    return Array.from(this.frostings.values());
  }
  
  async getFrosting(id: number): Promise<Frosting | undefined> {
    return this.frostings.get(id);
  }

  // Decoration operations
  async getAllDecorations(): Promise<Decoration[]> {
    return Array.from(this.decorations.values());
  }
  
  async getDecorationsByCategory(category: string): Promise<Decoration[]> {
    return Array.from(this.decorations.values()).filter(
      (decoration) => decoration.category === category
    );
  }
  
  async getDecoration(id: number): Promise<Decoration | undefined> {
    return this.decorations.get(id);
  }

  // Recipe operations
  async getAllRecipes(): Promise<Recipe[]> {
    return Array.from(this.recipes.values());
  }
  
  async getRecipesByType(type: string): Promise<Recipe[]> {
    return Array.from(this.recipes.values()).filter(
      (recipe) => recipe.type === type
    );
  }
  
  async getThemedRecipes(): Promise<Recipe[]> {
    return Array.from(this.recipes.values()).filter(
      (recipe) => recipe.isThemed === true
    );
  }
  
  async getRecipe(id: number): Promise<Recipe | undefined> {
    return this.recipes.get(id);
  }

  // Seed initial data
  private seedData() {
    // Create a test user with profile
    this.createUser({
      username: "testuser",
      password: "password",
      name: "Test User",
      email: "test@example.com",
      bio: "I love baking childhood favorites!",
      avatarUrl: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde"
    }).then(user => {
      // Create user profile
      this.createUserProfile({
        userId: user.id,
        favoriteFlavors: ["chocolate", "vanilla", "strawberry"],
        bakingLevel: "intermediate",
        achievements: ["first_cake", "master_baker", "decoration_expert"],
        bakingStreak: 5
      });
      
      // Create themed event
      this.createEvent({
        title: "Birthday Bash Memories",
        description: "Create treats inspired by your favorite childhood birthday memories",
        theme: "birthday",
        memoryDescription: "Remember the excitement of blowing out candles on your birthday cake? This event is all about recreating those special birthday treats that made your childhood celebrations magical.",
        imageUrl: "https://images.unsplash.com/photo-1464349153735-7db50ed83c84",
        startDate: new Date(new Date().setDate(new Date().getDate() - 5)),
        endDate: new Date(new Date().setDate(new Date().getDate() + 25)),
        isActive: true
      }).then(event => {
        // Add a recipe to the event
        this.addRecipeToEvent({
          eventId: event.id,
          recipeId: 3, // Confetti Birthday Cake
          isFeatured: true
        });
      });
      
      // Create another themed event
      this.createEvent({
        title: "School Lunch Box Treats",
        description: "Recreate your favorite childhood lunch box treats",
        theme: "school",
        memoryDescription: "Remember the joy of opening your lunch box to find your favorite treat? This event celebrates the nostalgic lunchtime sweets that made school days special.",
        imageUrl: "https://images.unsplash.com/photo-1599508704512-2f19efd1e35f",
        startDate: new Date(new Date().setDate(new Date().getDate() + 10)),
        endDate: new Date(new Date().setDate(new Date().getDate() + 40)),
        isActive: true
      });
    });
    
    // Add ingredients
    const baseIngredients = [
      { name: "All-Purpose Flour", category: "base", imageUrl: "https://images.unsplash.com/photo-1611861119313-31f0a8867f0a", available: true },
      { name: "Granulated Sugar", category: "base", imageUrl: "https://images.unsplash.com/photo-1582750433449-648ed127bb54", available: true },
      { name: "Unsalted Butter", category: "base", imageUrl: "https://images.unsplash.com/photo-1589985270826-4b7bb135bc9d", available: true },
      { name: "Eggs", category: "base", imageUrl: "https://images.unsplash.com/photo-1501529301789-b48c1975542a", available: true }
    ];
    
    baseIngredients.forEach(ingredient => {
      const id = this.ingredientId++;
      const now = new Date();
      this.ingredients.set(id, { ...ingredient, id, createdAt: now });
    });
    
    const flavorIngredients = [
      { name: "Vanilla Extract", category: "flavor", imageUrl: "https://images.unsplash.com/photo-1608321056927-70c6fa68444e", available: true },
      { name: "Cocoa Powder", category: "flavor", imageUrl: "https://images.unsplash.com/photo-1549007953-2f2dc0b24019", available: true },
      { name: "Cinnamon", category: "flavor", imageUrl: "https://images.unsplash.com/photo-1614158075291-817f8a6c9b7f", available: true }
    ];
    
    flavorIngredients.forEach(ingredient => {
      const id = this.ingredientId++;
      const now = new Date();
      this.ingredients.set(id, { ...ingredient, id, createdAt: now });
    });
    
    const mixinIngredients = [
      { name: "Chocolate Chips", category: "mix-in", imageUrl: "https://images.unsplash.com/photo-1614118996101-d1d556036cad", available: true },
      { name: "Chopped Nuts", category: "mix-in", imageUrl: "https://images.unsplash.com/photo-1604850486387-2cabb2e21c4b", available: true },
      { name: "Fresh Berries", category: "mix-in", imageUrl: "https://images.unsplash.com/photo-1563746924237-f81951d2e194", available: true }
    ];
    
    mixinIngredients.forEach(ingredient => {
      const id = this.ingredientId++;
      const now = new Date();
      this.ingredients.set(id, { ...ingredient, id, createdAt: now });
    });
    
    // Add frostings
    const frostingOptions = [
      { name: "Vanilla Buttercream", color: "#FEF3E0", imageUrl: "https://images.unsplash.com/photo-1586985290301-8db40143d525", available: true },
      { name: "Chocolate Ganache", color: "#4A3728", imageUrl: "https://images.unsplash.com/photo-1610611424854-5e07032154d7", available: true },
      { name: "Cream Cheese", color: "#FFF", imageUrl: "https://images.unsplash.com/photo-1588195544593-b2dec33bc09e", available: true },
      { name: "Salted Caramel", color: "#C68E17", imageUrl: "https://images.unsplash.com/photo-1589985270761-8c597be20f8f", available: true }
    ];
    
    frostingOptions.forEach(frosting => {
      const id = this.frostingId++;
      const now = new Date();
      this.frostings.set(id, { ...frosting, id, createdAt: now });
    });
    
    // Add decorations
    const decorationOptions = [
      { name: "Rainbow Sprinkles", category: "sprinkles", imageUrl: "https://images.unsplash.com/photo-1551529834-a42fe081b2d7", available: true },
      { name: "Chocolate Shavings", category: "chocolate", imageUrl: "https://images.unsplash.com/photo-1593095945039-7dd4df1b6d0e", available: true },
      { name: "Fresh Berries", category: "fruit", imageUrl: "https://images.unsplash.com/photo-1563746924237-f81951d2e194", available: true },
      { name: "Candy Pieces", category: "candy", imageUrl: "https://images.unsplash.com/photo-1555579406-c7142b48799a", available: true }
    ];
    
    decorationOptions.forEach(decoration => {
      const id = this.decorationId++;
      const now = new Date();
      this.decorations.set(id, { ...decoration, id, createdAt: now });
    });
    
    // Add recipes
    const recipeData = [
      {
        name: "Classic Chocolate Chip Cookies",
        type: "cookie",
        description: "Just like Grandma used to make! Soft, chewy cookies with melty chocolate chips.",
        ingredients: ["All-Purpose Flour", "Granulated Sugar", "Unsalted Butter", "Eggs", "Vanilla Extract", "Chocolate Chips"],
        steps: [
          "Preheat oven to 350°F (175°C).",
          "Cream together butter and sugar.",
          "Beat in eggs and vanilla.",
          "Add flour and mix until combined.",
          "Fold in chocolate chips.",
          "Drop rounded tablespoons onto baking sheets.",
          "Bake for 10-12 minutes until edges are golden."
        ],
        prepTime: 30,
        imageUrl: "https://images.unsplash.com/photo-1499636136210-6f4ee915583e",
        rating: 5,
        isThemed: false,
        memoryTags: []
      },
      {
        name: "Fudgy Chocolate Brownies",
        type: "brownie",
        description: "Rich, dense brownies with a crackly top and gooey center. Pure chocolate heaven!",
        ingredients: ["Unsalted Butter", "Granulated Sugar", "Eggs", "Cocoa Powder", "Vanilla Extract", "All-Purpose Flour"],
        steps: [
          "Preheat oven to 350°F (175°C).",
          "Melt butter and whisk in sugar.",
          "Add eggs and vanilla, mix well.",
          "Fold in cocoa powder and flour.",
          "Pour into a greased baking pan.",
          "Bake for 25-30 minutes.",
          "Let cool before cutting into squares."
        ],
        prepTime: 45,
        imageUrl: "https://images.unsplash.com/photo-1624353365286-3f8d62daad51",
        rating: 5,
        isThemed: true,
        memoryTags: ["afterschool", "weekend treat", "family favorite"]
      },
      {
        name: "Confetti Birthday Cake",
        type: "cake",
        description: "Colorful sprinkle-filled vanilla cake with creamy buttercream frosting.",
        ingredients: ["All-Purpose Flour", "Granulated Sugar", "Unsalted Butter", "Eggs", "Vanilla Extract", "Rainbow Sprinkles"],
        steps: [
          "Preheat oven to 350°F (175°C).",
          "Cream butter and sugar until light and fluffy.",
          "Add eggs one at a time, then vanilla.",
          "Gradually add flour mixture and milk.",
          "Fold in rainbow sprinkles.",
          "Divide batter between cake pans.",
          "Bake for 30-35 minutes.",
          "Cool and frost with vanilla buttercream."
        ],
        prepTime: 90,
        imageUrl: "https://images.unsplash.com/photo-1558301211-0d8c8ddee6ec",
        rating: 5,
        isThemed: true,
        memoryTags: ["birthday", "celebration", "childhood party"]
      },
      {
        name: "Gooey Cinnamon Rolls",
        type: "pastry",
        description: "Soft, fluffy rolls swirled with cinnamon sugar and topped with cream cheese frosting.",
        ingredients: ["All-Purpose Flour", "Granulated Sugar", "Unsalted Butter", "Eggs", "Cinnamon", "Cream Cheese"],
        steps: [
          "Make the dough and let rise until doubled.",
          "Roll out into a rectangle.",
          "Spread with butter and sprinkle with cinnamon sugar.",
          "Roll up tightly and cut into rounds.",
          "Place in a greased pan and let rise again.",
          "Bake at 350°F for 25-30 minutes.",
          "Top with cream cheese frosting while warm."
        ],
        prepTime: 120,
        imageUrl: "https://images.unsplash.com/photo-1509365465985-25d11c17e812",
        rating: 5,
        isThemed: false,
        memoryTags: []
      }
    ];
    
    recipeData.forEach(recipe => {
      const id = this.recipeId++;
      const now = new Date();
      this.recipes.set(id, { 
        ...recipe, 
        id,
        createdAt: now,
        updatedAt: now
      });
    });
  }
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set({
        ...userData,
        updatedAt: new Date()
      })
      .where(eq(users.id, id))
      .returning();
    
    return updatedUser || undefined;
  }

  // User Profile methods
  async getUserProfile(userId: number): Promise<UserProfile | undefined> {
    const [profile] = await db
      .select()
      .from(userProfiles)
      .where(eq(userProfiles.userId, userId));
    
    return profile || undefined;
  }

  async createUserProfile(profile: InsertUserProfile): Promise<UserProfile> {
    const [userProfile] = await db
      .insert(userProfiles)
      .values(profile)
      .returning();
    
    return userProfile;
  }

  async updateUserProfile(userId: number, profileData: Partial<InsertUserProfile>): Promise<UserProfile | undefined> {
    const [profile] = await db
      .update(userProfiles)
      .set({
        ...profileData,
        lastActive: new Date(),
        updatedAt: new Date()
      })
      .where(eq(userProfiles.userId, userId))
      .returning();
    
    return profile || undefined;
  }

  // BakedItem methods
  async getAllBakedItems(): Promise<BakedItem[]> {
    return await db.select().from(bakedItems);
  }

  async getBakedItemsByUserId(userId: number): Promise<BakedItem[]> {
    return await db
      .select()
      .from(bakedItems)
      .where(eq(bakedItems.userId, userId))
      .orderBy(desc(bakedItems.createdAt));
  }

  async getPublicBakedItems(limit?: number): Promise<BakedItem[]> {
    const query = db
      .select()
      .from(bakedItems)
      .where(eq(bakedItems.isPublic, true))
      .orderBy(desc(bakedItems.createdAt));
    
    if (limit) {
      return await query.limit(limit);
    }
    
    return await query;
  }

  async getBakedItem(id: number): Promise<BakedItem | undefined> {
    const [item] = await db
      .select()
      .from(bakedItems)
      .where(eq(bakedItems.id, id));
    
    return item || undefined;
  }

  async createBakedItem(insertItem: InsertBakedItem): Promise<BakedItem> {
    const [item] = await db
      .insert(bakedItems)
      .values(insertItem)
      .returning();
    
    return item;
  }

  async updateBakedItem(id: number, itemData: Partial<InsertBakedItem>): Promise<BakedItem | undefined> {
    const [item] = await db
      .update(bakedItems)
      .set({
        ...itemData,
        updatedAt: new Date()
      })
      .where(eq(bakedItems.id, id))
      .returning();
    
    return item || undefined;
  }

  async deleteBakedItem(id: number): Promise<boolean> {
    const result = await db
      .delete(bakedItems)
      .where(eq(bakedItems.id, id));
    
    return !!result;
  }

  // Favorites methods
  async getUserFavorites(userId: number): Promise<BakedItem[]> {
    const favItems = await db
      .select({
        bakedItem: bakedItems
      })
      .from(favorites)
      .innerJoin(bakedItems, eq(favorites.bakedItemId, bakedItems.id))
      .where(eq(favorites.userId, userId));
    
    return favItems.map(row => row.bakedItem);
  }

  async addFavorite(favorite: InsertFavorite): Promise<Favorite> {
    const [result] = await db
      .insert(favorites)
      .values(favorite)
      .returning();
    
    return result;
  }

  async removeFavorite(userId: number, bakedItemId: number): Promise<boolean> {
    const result = await db
      .delete(favorites)
      .where(
        and(
          eq(favorites.userId, userId),
          eq(favorites.bakedItemId, bakedItemId)
        )
      );
    
    return !!result;
  }

  async isFavorite(userId: number, bakedItemId: number): Promise<boolean> {
    const [result] = await db
      .select()
      .from(favorites)
      .where(
        and(
          eq(favorites.userId, userId),
          eq(favorites.bakedItemId, bakedItemId)
        )
      );
    
    return !!result;
  }

  // Event methods
  async getAllEvents(): Promise<Event[]> {
    return await db
      .select()
      .from(events)
      .orderBy(desc(events.startDate));
  }

  async getActiveEvents(): Promise<Event[]> {
    const now = new Date();
    
    return await db
      .select()
      .from(events)
      .where(
        and(
          eq(events.isActive, true),
          lte(events.startDate, now),
          gte(events.endDate, now)
        )
      )
      .orderBy(desc(events.startDate));
  }

  async getEvent(id: number): Promise<Event | undefined> {
    const [event] = await db
      .select()
      .from(events)
      .where(eq(events.id, id));
    
    return event || undefined;
  }

  async createEvent(insertEvent: InsertEvent): Promise<Event> {
    const [event] = await db
      .insert(events)
      .values(insertEvent)
      .returning();
    
    return event;
  }

  async updateEvent(id: number, eventData: Partial<InsertEvent>): Promise<Event | undefined> {
    const [event] = await db
      .update(events)
      .set({
        ...eventData,
        updatedAt: new Date()
      })
      .where(eq(events.id, id))
      .returning();
    
    return event || undefined;
  }

  async getEventParticipants(eventId: number): Promise<EventParticipant[]> {
    return await db
      .select()
      .from(eventParticipants)
      .where(eq(eventParticipants.eventId, eventId));
  }

  async joinEvent(participation: InsertEventParticipant): Promise<EventParticipant> {
    const [participant] = await db
      .insert(eventParticipants)
      .values(participation)
      .returning();
    
    return participant;
  }

  async leaveEvent(userId: number, eventId: number): Promise<boolean> {
    const result = await db
      .delete(eventParticipants)
      .where(
        and(
          eq(eventParticipants.userId, userId),
          eq(eventParticipants.eventId, eventId)
        )
      );
    
    return !!result;
  }

  async getEventRecipes(eventId: number): Promise<Recipe[]> {
    const recipeResults = await db
      .select({
        recipeData: recipes
      })
      .from(eventRecipes)
      .innerJoin(recipes, eq(eventRecipes.recipeId, recipes.id))
      .where(eq(eventRecipes.eventId, eventId));
    
    return recipeResults.map(row => row.recipeData);
  }

  async addRecipeToEvent(eventRecipe: InsertEventRecipe): Promise<EventRecipe> {
    const [result] = await db
      .insert(eventRecipes)
      .values(eventRecipe)
      .returning();
    
    return result;
  }

  async removeRecipeFromEvent(eventId: number, recipeId: number): Promise<boolean> {
    const result = await db
      .delete(eventRecipes)
      .where(
        and(
          eq(eventRecipes.eventId, eventId),
          eq(eventRecipes.recipeId, recipeId)
        )
      );
    
    return !!result;
  }

  // Ingredient methods
  async getAllIngredients(): Promise<Ingredient[]> {
    return await db.select().from(ingredients);
  }

  async getIngredientsByCategory(category: string): Promise<Ingredient[]> {
    return await db
      .select()
      .from(ingredients)
      .where(eq(ingredients.category, category));
  }

  async getIngredient(id: number): Promise<Ingredient | undefined> {
    const [ingredient] = await db
      .select()
      .from(ingredients)
      .where(eq(ingredients.id, id));
    
    return ingredient || undefined;
  }

  // Frosting methods
  async getAllFrostings(): Promise<Frosting[]> {
    return await db.select().from(frostings);
  }

  async getFrosting(id: number): Promise<Frosting | undefined> {
    const [frosting] = await db
      .select()
      .from(frostings)
      .where(eq(frostings.id, id));
    
    return frosting || undefined;
  }

  // Decoration methods
  async getAllDecorations(): Promise<Decoration[]> {
    return await db.select().from(decorations);
  }

  async getDecorationsByCategory(category: string): Promise<Decoration[]> {
    return await db
      .select()
      .from(decorations)
      .where(eq(decorations.category, category));
  }

  async getDecoration(id: number): Promise<Decoration | undefined> {
    const [decoration] = await db
      .select()
      .from(decorations)
      .where(eq(decorations.id, id));
    
    return decoration || undefined;
  }

  // Recipe methods
  async getAllRecipes(): Promise<Recipe[]> {
    return await db.select().from(recipes);
  }

  async getRecipesByType(type: string): Promise<Recipe[]> {
    return await db
      .select()
      .from(recipes)
      .where(eq(recipes.type, type));
  }

  async getThemedRecipes(): Promise<Recipe[]> {
    return await db
      .select()
      .from(recipes)
      .where(eq(recipes.isThemed, true));
  }

  async getRecipe(id: number): Promise<Recipe | undefined> {
    const [recipe] = await db
      .select()
      .from(recipes)
      .where(eq(recipes.id, id));
    
    return recipe || undefined;
  }
}

// Use MemStorage for now while we debug the database connection
export const storage = new MemStorage();
