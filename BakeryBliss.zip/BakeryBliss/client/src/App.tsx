import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Create from "@/pages/Create";
import GroceryArea from "@/pages/GroceryArea";
import BakingArea from "@/pages/BakingArea";
import FrostingArea from "@/pages/FrostingArea";
import DecorationArea from "@/pages/DecorationArea";
import FinalCreation from "@/pages/FinalCreation";
import ThemedEvents from "@/pages/ThemedEvents";
import EventDetail from "@/pages/EventDetail";
import UserProfile from "@/pages/UserProfile";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/create" component={Create} />
      <Route path="/grocery" component={GroceryArea} />
      <Route path="/baking" component={BakingArea} />
      <Route path="/frosting" component={FrostingArea} />
      <Route path="/decoration" component={DecorationArea} />
      <Route path="/final" component={FinalCreation} />
      <Route path="/events" component={ThemedEvents} />
      <Route path="/events/:id" component={EventDetail} />
      <Route path="/profile/:userId" component={UserProfile} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <TooltipProvider>
      <div className="flex flex-col min-h-screen">
        <Header />
        <main className="flex-grow">
          <Router />
        </main>
        <Footer />
      </div>
      <Toaster />
    </TooltipProvider>
  );
}

export default App;
