// Baking Types with their images
export const BAKING_TYPES = [
  { id: "cake", name: "Cake", image: "https://images.unsplash.com/photo-1588195538326-c5b1e9f80a1b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=800" },
  { id: "cookie", name: "Cookie", image: "https://images.unsplash.com/photo-1499636136210-6f4ee915583e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=800" },
  { id: "brownie", name: "Brownie", image: "https://images.unsplash.com/photo-1624353365286-3f8d62daad51?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=800" },
  { id: "pastry", name: "Pastry", image: "https://images.unsplash.com/photo-1509365465985-25d11c17e812?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=800" }
];

// Base types for each baking item
export const BASE_TYPES = {
  cake: [
    { id: "vanilla", name: "Vanilla Cake" },
    { id: "chocolate", name: "Chocolate Cake" },
    { id: "strawberry", name: "Strawberry Cake" },
    { id: "lemon", name: "Lemon Cake" }
  ],
  cookie: [
    { id: "chocolate-chip", name: "Chocolate Chip Cookie" },
    { id: "sugar", name: "Sugar Cookie" },
    { id: "oatmeal", name: "Oatmeal Cookie" },
    { id: "peanut-butter", name: "Peanut Butter Cookie" }
  ],
  brownie: [
    { id: "fudge", name: "Fudge Brownie" },
    { id: "caramel", name: "Caramel Brownie" },
    { id: "mint", name: "Mint Brownie" },
    { id: "walnut", name: "Walnut Brownie" }
  ],
  pastry: [
    { id: "cinnamon-roll", name: "Cinnamon Roll" },
    { id: "croissant", name: "Croissant" },
    { id: "danish", name: "Danish" },
    { id: "eclair", name: "Éclair" }
  ]
};

// Frosting types
export const FROSTING_TYPES = [
  { id: "buttercream", name: "Vanilla Buttercream" },
  { id: "chocolate", name: "Chocolate Ganache" },
  { id: "cream-cheese", name: "Cream Cheese" },
  { id: "caramel", name: "Salted Caramel" }
];

// Decoration types
export const DECORATION_TYPES = [
  { id: "sprinkles", name: "Rainbow Sprinkles" },
  { id: "fruit", name: "Fresh Berries" },
  { id: "chocolate", name: "Chocolate Shavings" },
  { id: "candy", name: "Candy Pieces" }
];

// Gallery items
export const GALLERY_ITEMS = [
  {
    id: 1,
    name: "Rainbow Birthday Cake",
    creator: "Sarah, 28",
    image: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=800"
  },
  {
    id: 2,
    name: "Classic Chocolate Chip Cookies",
    creator: "Miguel, 34",
    image: "https://images.unsplash.com/photo-1499636136210-6f4ee915583e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=800"
  },
  {
    id: 3,
    name: "Unicorn Cupcakes",
    creator: "Emma, 12",
    image: "https://images.unsplash.com/photo-1563729784474-d77dbb933a9e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=800"
  },
  {
    id: 4,
    name: "Dark Chocolate & Berry Cake",
    creator: "David, 42",
    image: "https://images.unsplash.com/photo-1606890737304-57a1ca8a5b62?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=800"
  },
  {
    id: 5,
    name: "Homestyle Cinnamon Rolls",
    creator: "Aisha, 29",
    image: "https://images.unsplash.com/photo-1509365465985-25d11c17e812?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=800"
  },
  {
    id: 6,
    name: "Triple Chocolate Brownies",
    creator: "Jackson, 15",
    image: "https://images.unsplash.com/photo-1624353365286-3f8d62daad51?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=800"
  }
];

// Testimonials
export const TESTIMONIALS = [
  {
    id: 1,
    name: "Jessica M.",
    initial: "J",
    rating: 5,
    color: "cafe-pink",
    text: "I brought my daughter here for her 10th birthday and we had the most amazing time! The staff was so helpful, and she was so proud of the cake we made together. We'll definitely be back!"
  },
  {
    id: 2,
    name: "Robert T.",
    initial: "R",
    rating: 4.5,
    color: "cafe-green",
    text: "Never thought I'd enjoy baking so much! The step-by-step process made it easy even for a complete beginner like me. The cookies I made actually tasted amazing - even my wife was impressed!"
  },
  {
    id: 3,
    name: "Maya K.",
    initial: "M",
    rating: 5,
    color: "cafe-purple",
    text: "What a wonderful concept! I organized a team building event here and everyone had a blast. The decoration zone was definitely our favorite part - so many options to get creative!"
  }
];
