import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export const recipeOptions = [
  {
    id: "cake",
    name: "Classic Cake",
    description: "A fluffy, moist vanilla cake that's perfect for any occasion",
    image: "cake.jpg",
  },
  {
    id: "cookie",
    name: "Chocolate Chip Cookies",
    description: "Soft, chewy cookies with plenty of chocolate chips",
    image: "cookie.jpg",
  },
  {
    id: "brownie",
    name: "Fudgy Brownies",
    description: "Rich, dense brownies with a crackly top and gooey center",
    image: "brownie.jpg",
  },
]

export const ingredients = [
  {
    id: "flour",
    name: "All-Purpose Flour",
    amount: "2 cups",
    icon: "bread-slice",
  },
  {
    id: "sugar",
    name: "Granulated Sugar",
    amount: "1 cup",
    icon: "cube",
  },
  {
    id: "butter",
    name: "Unsalted Butter",
    amount: "1/2 cup",
    icon: "square",
  },
  {
    id: "eggs",
    name: "Eggs",
    amount: "2 large",
    icon: "egg",
  },
  {
    id: "vanilla",
    name: "Vanilla Extract",
    amount: "1 tsp",
    icon: "vial",
  },
  {
    id: "milk",
    name: "Milk",
    amount: "1/2 cup",
    icon: "tint",
  },
]
