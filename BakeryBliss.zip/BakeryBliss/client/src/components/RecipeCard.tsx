import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import { Recipe } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";

interface RecipeCardProps {
  recipe: Recipe;
  index: number;
}

const RecipeCard = ({ recipe, index }: RecipeCardProps) => {
  return (
    <motion.div
      className="baking-card bg-white rounded-lg shadow-lg overflow-hidden transition-all duration-300"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.1 }}
    >
      <div className="h-48 overflow-hidden">
        <img 
          src={recipe.imageUrl} 
          alt={recipe.name} 
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
        />
      </div>
      <div className="p-5">
        <h3 className="font-bold text-xl mb-2">{recipe.name}</h3>
        <p className="text-gray-700 mb-4">{recipe.description}</p>
        <div className="flex items-center text-sm text-gray-500 mb-4">
          <span className="mr-3"><i className="ri-time-line mr-1"></i> {recipe.prepTime} mins</span>
          <span><i className="ri-star-fill mr-1 text-[#FFD700]"></i> {recipe.rating}</span>
        </div>
        <Link href="/create">
          <Button className="w-full bg-[#8B4513] hover:bg-[#C41E3A] text-white font-bold py-2 px-4 rounded transition duration-300">
            Start Baking
          </Button>
        </Link>
      </div>
    </motion.div>
  );
};

const RecipeTemplates = () => {
  const { data: recipes, isLoading } = useQuery({
    queryKey: ['/api/recipes'],
  });

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="font-pacifico text-4xl text-center text-[#8B4513] mb-4">Nostalgic Favorites</h2>
        <p className="text-center text-gray-700 mb-12 max-w-2xl mx-auto">
          Recreate these childhood classics or use them as inspiration for your own creations.
        </p>
        
        {isLoading ? (
          <div className="flex justify-center p-8">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#8B4513]"></div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {recipes?.slice(0, 4).map((recipe, index) => (
              <RecipeCard key={recipe.id} recipe={recipe} index={index} />
            ))}
          </div>
        )}
        
        <div className="text-center mt-10">
          <Button 
            variant="outline"
            className="bg-[#FFF8E1] text-[#8B4513] border-2 border-[#8B4513] hover:bg-[#8B4513] hover:text-white font-bold py-3 px-8 rounded-full transition duration-300"
          >
            See All Recipes
          </Button>
        </div>
      </div>
    </section>
  );
};

export default RecipeTemplates;
