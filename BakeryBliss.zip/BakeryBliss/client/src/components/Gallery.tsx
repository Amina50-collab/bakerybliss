import { useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';

interface GalleryItemProps {
  image: string;
  title: string;
  creator: string;
  index: number;
}

const GalleryItem = ({ image, title, creator, index }: GalleryItemProps) => {
  return (
    <motion.div 
      className="overflow-hidden rounded-lg shadow-lg"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.1 }}
    >
      <img 
        src={image} 
        alt={title} 
        className="w-full h-64 object-cover transition-transform duration-500 hover:scale-110" 
      />
      <div className="p-4 bg-white">
        <h3 className="font-bold">{title}</h3>
        <p className="text-sm text-gray-600">Created by {creator}</p>
      </div>
    </motion.div>
  );
};

const Gallery = () => {
  const { data: bakedItems, isLoading } = useQuery({
    queryKey: ['/api/baked-items'],
  });

  // Sample gallery data (when API data is unavailable)
  const galleryData = [
    {
      image: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=800",
      title: "Rainbow Birthday Cake",
      creator: "Sarah, 28"
    },
    {
      image: "https://images.unsplash.com/photo-1499636136210-6f4ee915583e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=800",
      title: "Classic Chocolate Chip Cookies",
      creator: "Miguel, 34"
    },
    {
      image: "https://images.unsplash.com/photo-1563729784474-d77dbb933a9e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=800",
      title: "Unicorn Cupcakes",
      creator: "Emma, 12"
    },
    {
      image: "https://images.unsplash.com/photo-1606890737304-57a1ca8a5b62?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=800",
      title: "Dark Chocolate & Berry Cake",
      creator: "David, 42"
    },
    {
      image: "https://images.unsplash.com/photo-1509365465985-25d11c17e812?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=800",
      title: "Homestyle Cinnamon Rolls",
      creator: "Aisha, 29"
    },
    {
      image: "https://images.unsplash.com/photo-1624353365286-3f8d62daad51?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=800",
      title: "Triple Chocolate Brownies",
      creator: "Jackson, 15"
    }
  ];

  return (
    <section className="py-16 bg-white" id="gallery">
      <div className="container mx-auto px-4">
        <h2 className="font-pacifico text-4xl text-center text-[#8B4513] mb-4">Bakery Gallery</h2>
        <p className="text-center text-gray-700 mb-12 max-w-2xl mx-auto">
          See what others have created in our café and get inspired!
        </p>
        
        {isLoading ? (
          <div className="flex justify-center p-8">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#8B4513]"></div>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {bakedItems && bakedItems.length > 0 ? (
              bakedItems.slice(0, 6).map((item, index) => (
                <GalleryItem 
                  key={item.id} 
                  image={item.imageUrl || galleryData[index % galleryData.length].image} 
                  title={item.name} 
                  creator={`User ${item.userId || 'Anonymous'}`} 
                  index={index}
                />
              ))
            ) : (
              galleryData.map((item, index) => (
                <GalleryItem 
                  key={index} 
                  image={item.image} 
                  title={item.title} 
                  creator={item.creator} 
                  index={index}
                />
              ))
            )}
          </div>
        )}
        
        <div className="text-center">
          <Button className="bg-[#6A5ACD] hover:bg-purple-700 text-white font-bold py-3 px-8 rounded-full shadow-lg transition duration-300">
            Show More Creations
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Gallery;
