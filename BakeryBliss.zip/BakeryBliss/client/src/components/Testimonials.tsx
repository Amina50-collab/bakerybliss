import { motion } from 'framer-motion';

const testimonials = [
  {
    initial: "J",
    name: "Jessica M.",
    bgColor: "bg-[#FFB6C1]",
    rating: 5,
    text: "I brought my daughter here for her 10th birthday and we had the most amazing time! The staff was so helpful, and she was so proud of the cake we made together. We'll definitely be back!"
  },
  {
    initial: "R",
    name: "Robert T.",
    bgColor: "bg-[#93C572]",
    rating: 4.5,
    text: "Never thought I'd enjoy baking so much! The step-by-step process made it easy even for a complete beginner like me. The cookies I made actually tasted amazing - even my wife was impressed!"
  },
  {
    initial: "M",
    name: "Maya K.",
    bgColor: "bg-[#6A5ACD]",
    rating: 5,
    text: "What a wonderful concept! I organized a team building event here and everyone had a blast. The decoration zone was definitely our favorite part - so many options to get creative!"
  }
];

const Testimonials = () => {
  return (
    <section className="py-16 bg-[#FFF8E1] bg-opacity-50">
      <div className="container mx-auto px-4">
        <h2 className="font-pacifico text-4xl text-center text-[#8B4513] mb-4">Sweet Memories</h2>
        <p className="text-center text-gray-700 mb-12 max-w-2xl mx-auto">
          Hear what our visitors have to say about their experience.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div 
              key={index}
              className="bg-white p-6 rounded-lg shadow-lg"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
            >
              <div className="flex items-center mb-4">
                <div className={`w-12 h-12 ${testimonial.bgColor} rounded-full flex items-center justify-center text-white font-bold text-xl`}>
                  {testimonial.initial}
                </div>
                <div className="ml-4">
                  <h3 className="font-bold">{testimonial.name}</h3>
                  <div className="flex text-[#FFD700]">
                    {[...Array(Math.floor(testimonial.rating))].map((_, i) => (
                      <i key={i} className="ri-star-fill"></i>
                    ))}
                    {testimonial.rating % 1 !== 0 && (
                      <i className="ri-star-half-fill"></i>
                    )}
                  </div>
                </div>
              </div>
              <p className="text-gray-700 italic">{testimonial.text}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
