import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useQuery } from '@tanstack/react-query';
import { Link } from "wouter";

const BakingZones = () => {
  const [selectedIngredients, setSelectedIngredients] = useState<string[]>([]);

  const { data: ingredients, isLoading: loadingIngredients } = useQuery({
    queryKey: ['/api/ingredients'],
  });

  const baseIngredients = ingredients?.filter((ing: any) => ing.category === 'base') || [];
  const flavorIngredients = ingredients?.filter((ing: any) => ing.category === 'flavor') || [];
  const mixinIngredients = ingredients?.filter((ing: any) => ing.category === 'mix-in') || [];

  const handleIngredientChange = (ingredient: string, checked: boolean) => {
    if (checked) {
      setSelectedIngredients(prev => [...prev, ingredient]);
    } else {
      setSelectedIngredients(prev => prev.filter(item => item !== ingredient));
    }
  };

  const handleContinue = () => {
    // Store selected ingredients in localStorage for demo purposes
    localStorage.setItem('selectedIngredients', JSON.stringify(selectedIngredients));
    // In a production app, we would use the BakeryContext to manage state
  };

  return (
    <section className="py-16 bg-[#FFF8E1]" id="baking-zones">
      <div className="container mx-auto px-4">
        <h2 className="font-pacifico text-4xl text-center text-[#8B4513] mb-4">Our Baking Zones</h2>
        <p className="text-center text-gray-700 mb-12 max-w-2xl mx-auto">
          Explore our four interactive areas where you can create your perfect baked goods from start to finish.
        </p>
        
        <Tabs defaultValue="grocery">
          <TabsList className="flex flex-wrap justify-center mb-8 border-b border-[#8B4513] bg-transparent w-full">
            <TabsTrigger value="grocery" className="bg-[#FFD700] text-white px-6 py-3 font-bold rounded-t-lg mx-1 focus:outline-none data-[state=active]:bg-[#FFD700] data-[state=active]:text-white">
              <i className="ri-shopping-basket-2-line mr-2"></i>Grocery
            </TabsTrigger>
            <TabsTrigger value="baking" className="bg-[#D2B48C] text-white px-6 py-3 font-bold rounded-t-lg mx-1 focus:outline-none data-[state=active]:bg-[#D2B48C] data-[state=active]:text-white">
              <i className="ri-bowl-line mr-2"></i>Baking
            </TabsTrigger>
            <TabsTrigger value="frosting" className="bg-[#FFB6C1] text-white px-6 py-3 font-bold rounded-t-lg mx-1 focus:outline-none data-[state=active]:bg-[#FFB6C1] data-[state=active]:text-white">
              <i className="ri-paint-brush-line mr-2"></i>Frosting
            </TabsTrigger>
            <TabsTrigger value="decoration" className="bg-[#6A5ACD] text-white px-6 py-3 font-bold rounded-t-lg mx-1 focus:outline-none data-[state=active]:bg-[#6A5ACD] data-[state=active]:text-white">
              <i className="ri-magic-line mr-2"></i>Decoration
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="grocery" className="mt-0">
            <div className="bg-white rounded-lg shadow-lg p-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h3 className="font-pacifico text-2xl text-[#8B4513] mb-4">Select Your Ingredients</h3>
                  <p className="text-gray-700 mb-6">
                    Choose from our wide variety of fresh, high-quality ingredients to start your baking adventure.
                  </p>
                  
                  {loadingIngredients ? (
                    <div className="flex justify-center p-8">
                      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#8B4513]"></div>
                    </div>
                  ) : (
                    <>
                      <div className="mb-6">
                        <h4 className="font-bold text-lg mb-3">Base Items</h4>
                        <div className="flex flex-wrap gap-3">
                          {baseIngredients.map((ingredient) => (
                            <div key={ingredient.id} className="p-2 border border-[#FFD700] rounded-lg flex items-center cursor-pointer hover:bg-[#FFF8E1]">
                              <Checkbox 
                                id={`ingredient-${ingredient.id}`} 
                                className="mr-2"
                                onCheckedChange={(checked) => handleIngredientChange(ingredient.name, checked === true)}
                              />
                              <Label htmlFor={`ingredient-${ingredient.id}`}>{ingredient.name}</Label>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      <div className="mb-6">
                        <h4 className="font-bold text-lg mb-3">Flavors</h4>
                        <div className="flex flex-wrap gap-3">
                          {flavorIngredients.map((ingredient) => (
                            <div key={ingredient.id} className="p-2 border border-[#FFB6C1] rounded-lg flex items-center cursor-pointer hover:bg-[#FFF8E1]">
                              <Checkbox 
                                id={`ingredient-${ingredient.id}`} 
                                className="mr-2"
                                onCheckedChange={(checked) => handleIngredientChange(ingredient.name, checked === true)}
                              />
                              <Label htmlFor={`ingredient-${ingredient.id}`}>{ingredient.name}</Label>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="font-bold text-lg mb-3">Mix-ins</h4>
                        <div className="flex flex-wrap gap-3">
                          {mixinIngredients.map((ingredient) => (
                            <div key={ingredient.id} className="p-2 border border-[#6A5ACD] rounded-lg flex items-center cursor-pointer hover:bg-[#FFF8E1]">
                              <Checkbox 
                                id={`ingredient-${ingredient.id}`} 
                                className="mr-2"
                                onCheckedChange={(checked) => handleIngredientChange(ingredient.name, checked === true)}
                              />
                              <Label htmlFor={`ingredient-${ingredient.id}`}>{ingredient.name}</Label>
                            </div>
                          ))}
                        </div>
                      </div>
                    </>
                  )}
                </div>
                
                <div>
                  <div className="rounded-lg overflow-hidden shadow-lg h-80">
                    <img 
                      src="https://pixabay.com/get/g521a4aa4c930b38fa6850675bc4cf8f78cd8eb3c32893ace4b0f39e212b1483701e63d2fb407616c8e33d5ddc0293d18d082356579804736ccb0269d9b540718_1280.jpg" 
                      alt="Baking ingredients and supplies" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  
                  <div className="mt-6 p-4 bg-[#FFD700] bg-opacity-10 rounded-lg">
                    <h4 className="font-bold text-lg mb-2">Your Shopping Basket</h4>
                    <ul className="list-disc pl-5 mb-4 min-h-[100px]">
                      {selectedIngredients.length === 0 ? (
                        <li className="text-gray-700">Select ingredients to see them here</li>
                      ) : (
                        selectedIngredients.map((ingredient, index) => (
                          <li key={index} className="text-gray-700">{ingredient}</li>
                        ))
                      )}
                    </ul>
                    <Button 
                      className="bg-[#FFD700] hover:bg-yellow-600 text-white font-bold py-2 px-4 rounded-full shadow transition duration-300"
                      onClick={handleContinue}
                      disabled={selectedIngredients.length === 0}
                      asChild
                    >
                      <Link href="/baking">
                        Continue to Baking Zone
                      </Link>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="baking">
            <div className="bg-white rounded-lg shadow-lg p-8 text-center">
              <h3 className="font-pacifico text-2xl text-[#8B4513] mb-4">Baking Zone</h3>
              <p className="text-gray-700 mb-6">
                Mix your ingredients and prepare your dough or batter for baking.
              </p>
              <div className="p-8 border-2 border-dashed border-[#D2B48C] rounded-lg">
                <i className="ri-bowl-line text-5xl text-[#D2B48C] mb-4 block"></i>
                <p className="text-lg">Select ingredients in the Grocery Zone first</p>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="frosting">
            <div className="bg-white rounded-lg shadow-lg p-8 text-center">
              <h3 className="font-pacifico text-2xl text-[#8B4513] mb-4">Frosting Zone</h3>
              <p className="text-gray-700 mb-6">
                Add delicious frostings to your baked goods.
              </p>
              <div className="p-8 border-2 border-dashed border-[#FFB6C1] rounded-lg">
                <i className="ri-paint-brush-line text-5xl text-[#FFB6C1] mb-4 block"></i>
                <p className="text-lg">Complete the Baking Zone first</p>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="decoration">
            <div className="bg-white rounded-lg shadow-lg p-8 text-center">
              <h3 className="font-pacifico text-2xl text-[#8B4513] mb-4">Decoration Zone</h3>
              <p className="text-gray-700 mb-6">
                Add the final touches with decorations and toppings.
              </p>
              <div className="p-8 border-2 border-dashed border-[#6A5ACD] rounded-lg">
                <i className="ri-magic-line text-5xl text-[#6A5ACD] mb-4 block"></i>
                <p className="text-lg">Complete the Frosting Zone first</p>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
};

export default BakingZones;
