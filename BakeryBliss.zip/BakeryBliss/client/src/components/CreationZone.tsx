import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { useBakery } from '@/contexts/BakeryContext';

const CreationZone = () => {
  const { basket, currentZone, addToBasket, setCurrentZone } = useBakery();
  const [baseSelection, setBaseSelection] = useState<string>("");
  const [frostingSelection, setFrostingSelection] = useState<string>("");
  const [decorations, setDecorations] = useState<string[]>([]);
  const [timerRunning, setTimerRunning] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [showPreview, setShowPreview] = useState(false);

  const { data: frostings } = useQuery({ queryKey: ['/api/frostings'] });
  const { data: decorationOptions } = useQuery({ queryKey: ['/api/decorations'] });

  // Timer functionality
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (timerRunning) {
      interval = setInterval(() => {
        setSeconds(prev => prev + 1);
      }, 1000);
    }
    
    return () => clearInterval(interval);
  }, [timerRunning]);

  const formatTime = () => {
    const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
    const secs = (seconds % 60).toString().padStart(2, '0');
    return `${mins}:${secs}`;
  };

  const handleStartTimer = () => {
    setTimerRunning(true);
  };

  const handleResetTimer = () => {
    setTimerRunning(false);
    setSeconds(0);
  };

  const handleBaseChange = (value: string) => {
    setBaseSelection(value);
    addToBasket(value);
    setShowPreview(true);
  };

  const handleFrostingChange = (value: string) => {
    setFrostingSelection(value);
    addToBasket(value);
    setShowPreview(true);
  };

  const handleDecorationChange = (value: string, checked: boolean) => {
    if (checked) {
      setDecorations(prev => [...prev, value]);
      addToBasket(value);
    } else {
      setDecorations(prev => prev.filter(item => item !== value));
    }
    setShowPreview(true);
  };

  const handleCreateTreat = () => {
    // Submit to API or proceed to next step
    // For now, just move to the next zone
    if (currentZone < 4) {
      setCurrentZone(currentZone + 1);
    }
  };

  return (
    <section className="py-16 bg-[#FFF8E1] bg-opacity-40">
      <div className="container mx-auto px-4">
        <h2 className="font-pacifico text-4xl text-center text-[#8B4513] mb-4">Design Your Creation</h2>
        <p className="text-center text-gray-700 mb-12 max-w-2xl mx-auto">
          Follow the steps to create your own personalized baked goods.
        </p>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left sidebar - Options */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="font-bold text-xl mb-4 text-[#8B4513]">Customize Your Treat</h3>
              
              {/* Baking Options */}
              <div className="mb-6">
                <h4 className="font-bold text-[#8B4513] mb-3">Choose Your Base</h4>
                <RadioGroup value={baseSelection} onValueChange={handleBaseChange}>
                  <div className="space-y-2">
                    <div className="flex items-center cursor-pointer p-2 hover:bg-[#FFF8E1] hover:bg-opacity-30 rounded">
                      <RadioGroupItem value="Vanilla Cake" id="base-cake" className="mr-2" />
                      <Label htmlFor="base-cake">Vanilla Cake</Label>
                    </div>
                    <div className="flex items-center cursor-pointer p-2 hover:bg-[#FFF8E1] hover:bg-opacity-30 rounded">
                      <RadioGroupItem value="Chocolate Cookie" id="base-cookie" className="mr-2" />
                      <Label htmlFor="base-cookie">Chocolate Cookie</Label>
                    </div>
                    <div className="flex items-center cursor-pointer p-2 hover:bg-[#FFF8E1] hover:bg-opacity-30 rounded">
                      <RadioGroupItem value="Fudge Brownie" id="base-brownie" className="mr-2" />
                      <Label htmlFor="base-brownie">Fudge Brownie</Label>
                    </div>
                    <div className="flex items-center cursor-pointer p-2 hover:bg-[#FFF8E1] hover:bg-opacity-30 rounded">
                      <RadioGroupItem value="Flaky Pastry" id="base-pastry" className="mr-2" />
                      <Label htmlFor="base-pastry">Flaky Pastry</Label>
                    </div>
                  </div>
                </RadioGroup>
              </div>
              
              {/* Frosting Options */}
              <div className="mb-6">
                <h4 className="font-bold text-[#FFB6C1] mb-3">Select Your Frosting</h4>
                <RadioGroup value={frostingSelection} onValueChange={handleFrostingChange}>
                  <div className="space-y-2">
                    {frostings?.map(frosting => (
                      <div key={frosting.id} className="flex items-center cursor-pointer p-2 hover:bg-[#FFF8E1] hover:bg-opacity-30 rounded">
                        <RadioGroupItem value={frosting.name} id={`frosting-${frosting.id}`} className="mr-2" />
                        <Label htmlFor={`frosting-${frosting.id}`}>{frosting.name}</Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
              </div>
              
              {/* Decoration Options */}
              <div className="mb-6">
                <h4 className="font-bold text-[#6A5ACD] mb-3">Add Decorations</h4>
                <div className="space-y-2">
                  {decorationOptions?.map(decoration => (
                    <div key={decoration.id} className="flex items-center cursor-pointer p-2 hover:bg-[#FFF8E1] hover:bg-opacity-30 rounded">
                      <Checkbox 
                        id={`decoration-${decoration.id}`} 
                        className="mr-2"
                        checked={decorations.includes(decoration.name)}
                        onCheckedChange={(checked) => handleDecorationChange(decoration.name, checked === true)} 
                      />
                      <Label htmlFor={`decoration-${decoration.id}`}>{decoration.name}</Label>
                    </div>
                  ))}
                </div>
              </div>
              
              <Button 
                className="w-full bg-[#8B4513] hover:bg-[#C41E3A] text-white font-bold py-3 px-4 rounded-full transition duration-300"
                onClick={handleCreateTreat}
                disabled={!baseSelection || !frostingSelection}
              >
                Create My Treat
              </Button>
            </div>
          </div>
          
          {/* Middle - Preview */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="font-bold text-xl mb-4 text-[#8B4513]">Preview</h3>
              
              <div className="bg-[#FFF8E1] bg-opacity-20 rounded-lg p-4 mb-4">
                {!showPreview && <p className="text-center text-gray-500 italic">Select options to preview your creation</p>}
                
                {/* Cake/cookie preview image placeholder */}
                <div className="h-64 flex items-center justify-center border-2 border-dashed border-gray-300 rounded-lg mt-4">
                  {showPreview ? (
                    <img 
                      id="preview-image" 
                      src="https://images.unsplash.com/photo-1578985545062-69928b1d9587?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=800" 
                      alt="Preview of your creation" 
                      className="max-h-full max-w-full rounded-lg"
                    />
                  ) : (
                    <div className="text-gray-400 text-center">
                      <i className="ri-cake-3-line text-5xl mb-2"></i>
                      <p>Your creation will appear here</p>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="space-y-2 mb-4">
                <div className="flex justify-between">
                  <span className="font-medium">Base:</span>
                  <span className="text-gray-700">{baseSelection || "Not selected"}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Frosting:</span>
                  <span className="text-gray-700">{frostingSelection || "Not selected"}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Decorations:</span>
                  <span className="text-gray-700">{decorations.length > 0 ? decorations.join(', ') : "Not selected"}</span>
                </div>
              </div>
            </div>
          </div>
          
          {/* Right sidebar - Progress */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-lg p-6">
              <h3 className="font-bold text-xl mb-4 text-[#8B4513]">Your Progress</h3>
              
              <div className="mb-6">
                <div className="flex items-center mb-2">
                  <div className={`w-8 h-8 rounded-full ${currentZone >= 1 ? 'bg-[#FFD700]' : 'bg-gray-300'} flex items-center justify-center mr-3`}>
                    {currentZone > 1 ? <i className="ri-check-line text-white"></i> : <span className="text-white text-sm font-bold">1</span>}
                  </div>
                  <div>
                    <h4 className="font-bold">Grocery Zone</h4>
                    <p className="text-sm text-gray-600">Ingredients selected</p>
                  </div>
                </div>
                
                <div className="w-px h-6 bg-gray-300 ml-4 my-1"></div>
                
                <div className="flex items-center mb-2">
                  <div className={`w-8 h-8 rounded-full ${currentZone >= 2 ? 'bg-[#D2B48C]' : 'bg-gray-300'} flex items-center justify-center mr-3`}>
                    {currentZone > 2 ? <i className="ri-check-line text-white"></i> : <span className="text-white text-sm font-bold">2</span>}
                  </div>
                  <div>
                    <h4 className="font-bold">Baking Zone</h4>
                    <p className="text-sm text-gray-600">Mix and bake your creation</p>
                  </div>
                </div>
                
                <div className="w-px h-6 bg-gray-300 ml-4 my-1"></div>
                
                <div className="flex items-center mb-2 opacity-50">
                  <div className={`w-8 h-8 rounded-full ${currentZone >= 3 ? 'bg-[#FFB6C1]' : 'bg-gray-300'} flex items-center justify-center mr-3`}>
                    {currentZone > 3 ? <i className="ri-check-line text-white"></i> : <span className="text-white text-sm font-bold">3</span>}
                  </div>
                  <div>
                    <h4 className="font-bold">Frosting Zone</h4>
                    <p className="text-sm text-gray-600">Add delicious frosting</p>
                  </div>
                </div>
                
                <div className="w-px h-6 bg-gray-300 ml-4 my-1"></div>
                
                <div className="flex items-center opacity-50">
                  <div className={`w-8 h-8 rounded-full ${currentZone >= 4 ? 'bg-[#6A5ACD]' : 'bg-gray-300'} flex items-center justify-center mr-3`}>
                    {currentZone > 4 ? <i className="ri-check-line text-white"></i> : <span className="text-white text-sm font-bold">4</span>}
                  </div>
                  <div>
                    <h4 className="font-bold">Decoration Zone</h4>
                    <p className="text-sm text-gray-600">Add the final touches</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-[#FFF8E1] bg-opacity-30 rounded-lg p-4">
                <h4 className="font-bold mb-2">Baking Timer</h4>
                <div className="flex items-center justify-center p-3 bg-white rounded-lg">
                  <span className="text-3xl font-bold text-[#8B4513]">{formatTime()}</span>
                </div>
                <div className="grid grid-cols-2 gap-2 mt-3">
                  <Button 
                    className="bg-[#93C572] text-white py-2 rounded font-bold"
                    onClick={handleStartTimer}
                    disabled={timerRunning}
                  >
                    Start
                  </Button>
                  <Button 
                    className="bg-[#C41E3A] text-white py-2 rounded font-bold"
                    onClick={handleResetTimer}
                  >
                    Reset
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CreationZone;
