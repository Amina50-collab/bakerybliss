import { Link } from "wouter";

const Footer = () => {
  return (
    <footer className="bg-[#8B4513] bg-opacity-90 text-white py-12" id="contact">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="font-pacifico text-2xl mb-4">Childhood Bakery Café</h3>
            <p className="mb-4">"Turn your childhood into reality"</p>
            <div className="flex space-x-4">
              <a href="#" className="text-white hover:text-[#FFF8E1]">
                <i className="ri-facebook-fill text-xl"></i>
              </a>
              <a href="#" className="text-white hover:text-[#FFF8E1]">
                <i className="ri-instagram-line text-xl"></i>
              </a>
              <a href="#" className="text-white hover:text-[#FFF8E1]">
                <i className="ri-twitter-fill text-xl"></i>
              </a>
              <a href="#" className="text-white hover:text-[#FFF8E1]">
                <i className="ri-pinterest-fill text-xl"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-bold text-lg mb-4">Café Hours</h4>
            <ul className="space-y-2">
              <li>Monday - Friday: 9am - 8pm</li>
              <li>Saturday: 8am - 9pm</li>
              <li>Sunday: 10am - 6pm</li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold text-lg mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><Link href="/create"><a className="hover:text-[#FFF8E1]">Create Baked Good</a></Link></li>
              <li><a href="#" className="hover:text-[#FFF8E1]">Recipes</a></li>
              <li><a href="#" className="hover:text-[#FFF8E1]">Classes & Events</a></li>
              <li><a href="#" className="hover:text-[#FFF8E1]">Gift Cards</a></li>
              <li><a href="#" className="hover:text-[#FFF8E1]">FAQ</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-bold text-lg mb-4">Contact Us</h4>
            <ul className="space-y-2">
              <li className="flex items-start">
                <i className="ri-map-pin-line mt-1 mr-2"></i>
                <span>123 Baking Street, Sweetville, CA 90210</span>
              </li>
              <li className="flex items-start">
                <i className="ri-phone-line mt-1 mr-2"></i>
                <span>(555) 123-4567</span>
              </li>
              <li className="flex items-start">
                <i className="ri-mail-line mt-1 mr-2"></i>
                <span>hello@childhoodbakery.com</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-white border-opacity-20 mt-8 pt-8 text-center text-sm">
          <p>&copy; 2023 Childhood Bakery Café. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
