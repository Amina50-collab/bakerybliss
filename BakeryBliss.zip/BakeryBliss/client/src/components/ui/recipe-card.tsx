import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface RecipeCardProps {
  title: string;
  description: string;
  image: string;
  recipeId: string;
}

export function RecipeCard({
  title,
  description,
  image,
  recipeId
}: RecipeCardProps) {
  return (
    <Card className="recipe-card bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition-shadow">
      <div className="h-48 overflow-hidden">
        <img 
          src={image}
          alt={title}
          className="w-full h-full object-cover"
        />
      </div>
      <div className="p-4">
        <h3 className="font-display text-lg mb-1">{title}</h3>
        <p className="text-sm text-gray-600 mb-3">{description}</p>
        <Button 
          className="text-sm bg-primary/10 text-primary py-1 px-3 h-auto rounded-full font-medium"
          variant="ghost"
        >
          Make This
        </Button>
      </div>
    </Card>
  );
}
