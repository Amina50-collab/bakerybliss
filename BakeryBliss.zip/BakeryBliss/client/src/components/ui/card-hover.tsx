import { cn } from "@/lib/utils";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "wouter";

interface CardHoverProps extends React.HTMLAttributes<HTMLDivElement> {
  className?: string;
  title: string;
  description: string;
  image: string;
  color: string;
  buttonText: string;
  href: string;
  step: number;
}

export function CardHover({
  className,
  title,
  description,
  image,
  color,
  buttonText,
  href,
  step,
  ...props
}: CardHoverProps) {
  const colorClasses: Record<string, string> = {
    primary: "bg-primary text-white hover:bg-primary/90",
    secondary: "bg-secondary text-white hover:bg-secondary/90",
    accent: "bg-accent text-white hover:bg-accent/90",
    mint: "bg-mint text-white hover:bg-mint/90"
  };

  return (
    <Card 
      className={cn(
        "area-card overflow-hidden", 
        className
      )} 
      {...props}
    >
      <div className="h-48 overflow-hidden">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover"
        />
      </div>
      <CardContent className="p-5">
        <div className={`w-full h-2 rounded-full mb-4 bg-${color}`}></div>
        <h3 className="font-display text-xl mb-2">
          {step}. {title}
        </h3>
        <CardDescription className="mb-4">{description}</CardDescription>
        <Link href={href}>
          <a className={`w-full ${colorClasses[color]} py-2 px-4 rounded-lg font-bold transition-colors block text-center`}>
            {buttonText}
          </a>
        </Link>
      </CardContent>
    </Card>
  );
}
