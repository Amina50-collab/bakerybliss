import React from "react";
import { cn } from "@/lib/utils";
import { Card } from "@/components/ui/card";
import { motion } from "framer-motion";

interface SelectionItemProps {
  id: string;
  title: string;
  description: string;
  selected: boolean;
  onClick: () => void;
  color?: string;
  size?: "default" | "small";
}

export function SelectionItem({
  id,
  title,
  description,
  selected,
  onClick,
  color = "#8B4513",
  size = "default"
}: SelectionItemProps) {
  return (
    <Card
      key={id}
      className={cn(
        "p-4 cursor-pointer overflow-hidden transition-all duration-300",
        selected ? "border-2 shadow-md" : "border border-gray-200 hover:border-gray-300 hover:shadow-sm",
        size === "small" ? "p-3" : "p-4"
      )}
      style={{
        borderColor: selected ? color : undefined
      }}
      onClick={onClick}
    >
      <div className="flex items-start gap-3">
        <div
          className={cn(
            "rounded-full min-w-[24px] h-6 flex items-center justify-center mt-1",
            size === "small" ? "w-5 h-5 mt-0.5" : "w-6 h-6 mt-1"
          )}
          style={{ backgroundColor: selected ? color : "#e0e0e0" }}
        >
          {selected ? (
            <motion.svg
              className="text-white"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              width="12"
              height="12"
              viewBox="0 0 12 12"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M10 3L4.5 8.5L2 6"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </motion.svg>
          ) : null}
        </div>
        <div className="flex-1">
          <h3
            className={cn(
              "font-semibold",
              size === "small" ? "text-sm" : "text-base"
            )}
            style={{ color: selected ? color : undefined }}
          >
            {title}
          </h3>
          <p
            className={cn(
              "text-gray-600",
              size === "small" ? "text-xs" : "text-sm"
            )}
          >
            {description}
          </p>
        </div>
      </div>
    </Card>
  );
}