import { Link } from "wouter";
import { User, CalendarDays } from "lucide-react";
import { Button } from "@/components/ui/button";

const Header = () => {
  // For demo purposes, we'll use userId 1
  const userId = 1;

  return (
    <header className="bg-[#FFF8E1] shadow-md">
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <Link href="/">
            <div className="flex items-center mb-4 md:mb-0 cursor-pointer">
              <div className="text-[#8B4513] mr-3">
                <i className="ri-cake-3-line text-4xl"></i>
              </div>
              <div>
                <h1 className="font-pacifico text-3xl text-[#8B4513]">Childhood Bakery Café</h1>
                <p className="text-[#8B4513] italic text-sm">"Turn your childhood into reality"</p>
              </div>
            </div>
          </Link>
          <nav className="flex flex-wrap gap-6 justify-center">
            <Link href="/">
              <span className="text-[#8B4513] hover:text-[#C41E3A] font-semibold cursor-pointer">Home</span>
            </Link>
            <Link href="/create">
              <span className="text-[#8B4513] hover:text-[#C41E3A] font-semibold cursor-pointer">Create</span>
            </Link>
            <Link href="/events">
              <span className="text-[#8B4513] hover:text-[#C41E3A] font-semibold cursor-pointer flex items-center">
                <CalendarDays className="mr-1 h-4 w-4" />
                Events
              </span>
            </Link>
            <Link href="/profile/1">
              <span className="text-[#8B4513] hover:text-[#C41E3A] font-semibold cursor-pointer flex items-center">
                <User className="mr-1 h-4 w-4" />
                My Profile
              </span>
            </Link>
            <Link href="/#gallery">
              <span className="text-[#8B4513] hover:text-[#C41E3A] font-semibold cursor-pointer">Gallery</span>
            </Link>
            <a href="#contact" className="text-[#8B4513] hover:text-[#C41E3A] font-semibold cursor-pointer">Contact</a>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;
