import { motion } from "framer-motion";
import { Link } from "wouter";

const ProcessFlow = () => {
  const processes = [
    {
      icon: "ri-shopping-basket-2-line",
      title: "1. Grocery",
      description: "Select your ingredients from our fully-stocked pantry.",
      bgColor: "bg-[#FFD700]",
      hasArrow: true,
      path: "/grocery"
    },
    {
      icon: "ri-bowl-line",
      title: "2. Baking",
      description: "Mix, prepare, and bake your creations to perfection.",
      bgColor: "bg-[#D2B48C]",
      hasArrow: true,
      path: "/baking"
    },
    {
      icon: "ri-paint-brush-line",
      title: "3. Frosting",
      description: "Add delicious frostings in a variety of flavors.",
      bgColor: "bg-[#FFB6C1]",
      hasArrow: true,
      path: "/frosting"
    },
    {
      icon: "ri-magic-line",
      title: "4. Decoration",
      description: "Personalize with toppings, sprinkles, and designs.",
      bgColor: "bg-[#6A5ACD]",
      hasArrow: false,
      path: "/decoration"
    }
  ];

  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="font-pacifico text-3xl text-center text-[#8B4513] mb-12">Our Baking Journey</h2>
        
        <div className="flex flex-col md:flex-row justify-between items-center md:items-start space-y-8 md:space-y-0 md:space-x-4">
          {processes.map((process, index) => (
            <Link key={index} href={process.path}>
              <motion.div
                className={`process-step ${process.hasArrow ? 'process-arrow' : ''} w-full md:w-1/4 flex flex-col items-center cursor-pointer transition-transform duration-300 hover:translate-y-[-8px]`}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <div className={`w-20 h-20 rounded-full ${process.bgColor} flex items-center justify-center mb-4`}>
                  <i className={`${process.icon} text-white text-3xl`}></i>
                </div>
                <h3 className="font-bold text-xl mb-2">{process.title}</h3>
                <p className="text-center text-gray-600">{process.description}</p>
              </motion.div>
            </Link>
          ))}
        </div>
        
        <div className="text-center mt-10">
          <Link href="/create">
            <button className="bg-[#8B4513] hover:bg-[#8B4513]/80 text-white font-bold py-3 px-8 rounded-full shadow-lg transition duration-300 mt-6">
              Start Your Baking Journey
            </button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default ProcessFlow;
