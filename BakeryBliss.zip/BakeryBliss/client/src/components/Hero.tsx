import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

const Hero = () => {
  return (
    <section className="relative">
      <div 
        className="w-full h-[500px] bg-cover bg-center relative" 
        style={{ backgroundImage: "url('https://images.unsplash.com/photo-1555396273-367ea4eb4db5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')", backgroundPosition: "center" }}
      >
        <div className="absolute inset-0 bg-[#8B4513] bg-opacity-40"></div>
        <div className="container mx-auto px-4 h-full flex items-center relative z-10">
          <motion.div 
            className="max-w-2xl text-white"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="font-pacifico text-5xl mb-4">Create Sweet Memories</h2>
            <p className="text-xl mb-8">Make and enjoy your own baked creations in our interactive café experience</p>
            <Link href="/create">
              <Button 
                className="bg-[#C41E3A] hover:bg-red-700 text-white font-bold py-3 px-8 rounded-full shadow-lg transition duration-300"
                size="lg"
              >
                Start Baking Now
              </Button>
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
