import React from 'react';
import { Link } from 'wouter';
import { useBakingFlow } from '@/hooks/use-baking-flow';

interface ProgressIndicatorProps {
  currentStep: number;
  stepTitle: string;
  stepColor: string;
  prevPath: string;
  prevArea: string;
}

export default function ProgressIndicator({
  currentStep,
  stepTitle,
  stepColor,
  prevPath,
  prevArea
}: ProgressIndicatorProps) {
  const { setCurrentStep } = useBakingFlow();
  
  const steps = [
    { id: 1, name: 'Grocery', path: '/grocery', color: '#FFD700' },
    { id: 2, name: 'Baking', path: '/baking', color: '#D2B48C' },
    { id: 3, name: 'Frosting', path: '/frosting', color: '#FFB6C1' },
    { id: 4, name: 'Decoration', path: '/decoration', color: '#6A5ACD' },
    { id: 5, name: 'Final Creation', path: '/final', color: '#8B4513' }
  ];

  const handlePrev = () => {
    setCurrentStep(currentStep - 1);
  };

  const handleNext = () => {
    setCurrentStep(currentStep + 1);
  };

  const nextPath = currentStep < 5 ? steps[currentStep].path : '';
  const nextArea = currentStep < 5 ? steps[currentStep].name : '';

  return (
    <div className="w-full bg-white shadow-md py-4 mb-8 rounded-lg">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div 
              className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold" 
              style={{ backgroundColor: stepColor }}
            >
              {currentStep}
            </div>
            <h2 className="text-xl font-semibold" style={{ color: stepColor }}>{stepTitle}</h2>
          </div>
          
          <div className="flex gap-4 items-center">
            <div className="hidden md:flex">
              {steps.map((step) => (
                <Link 
                  key={step.id} 
                  href={step.path}
                  onClick={() => setCurrentStep(step.id)}
                >
                  <div 
                    className={`w-8 h-8 rounded-full flex items-center justify-center mx-1 cursor-pointer ${currentStep === step.id ? 'border-2 font-bold' : 'opacity-50'}`}
                    style={{ 
                      backgroundColor: step.id <= currentStep ? step.color : '#e0e0e0',
                      borderColor: step.color
                    }}
                  >
                    <span className="text-xs text-white">{step.id}</span>
                  </div>
                </Link>
              ))}
            </div>
            
            <div className="flex gap-2">
              {currentStep > 1 && (
                <Link href={prevPath} onClick={handlePrev}>
                  <button 
                    className="px-4 py-2 rounded-lg flex items-center gap-1 hover:bg-gray-100"
                  >
                    <span className="text-sm">← Back to {prevArea}</span>
                  </button>
                </Link>
              )}
              
              {currentStep < 5 && (
                <Link href={nextPath} onClick={handleNext}>
                  <button 
                    className="px-4 py-2 rounded-lg flex items-center gap-1 text-white"
                    style={{ backgroundColor: steps[currentStep].color }}
                  >
                    <span className="text-sm">Continue to {nextArea} →</span>
                  </button>
                </Link>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}