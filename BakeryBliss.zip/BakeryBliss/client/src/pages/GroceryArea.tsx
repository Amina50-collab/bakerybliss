import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useBakingFlow } from '@/hooks/use-baking-flow';
import { useQuery } from '@tanstack/react-query';
import { Card } from '@/components/ui/card';
import { SelectionItem } from '@/components/ui/selection-item';
import ProgressIndicator from '@/components/ProgressIndicator';

// Mock data
const recipeOptions = [
  {
    id: "cake",
    name: "Classic Vanilla Cake",
    description: "A fluffy, moist vanilla cake that reminds you of childhood birthdays",
    image: "/images/vanilla-cake.jpg",
    ingredients: ["Flour", "Sugar", "Eggs", "Vanilla Extract", "Butter", "Milk"]
  },
  {
    id: "cookies",
    name: "Chocolate Chip Cookies",
    description: "Warm, gooey chocolate chip cookies just like grandma used to make",
    image: "/images/chocolate-chip-cookies.jpg",
    ingredients: ["Flour", "Sugar", "Brown Sugar", "Eggs", "Butter", "Chocolate Chips", "Vanilla Extract"]
  },
  {
    id: "brownies",
    name: "Fudgy Brownies",
    description: "Rich, fudgy brownies with a crackly top and gooey center",
    image: "/images/brownies.jpg",
    ingredients: ["Flour", "Sugar", "Eggs", "Butter", "Cocoa Powder", "Chocolate Chips"]
  },
  {
    id: "cupcakes",
    name: "Funfetti Cupcakes",
    description: "Colorful cupcakes filled with sprinkles for a touch of childhood magic",
    image: "/images/funfetti-cupcakes.jpg",
    ingredients: ["Flour", "Sugar", "Eggs", "Butter", "Milk", "Vanilla Extract", "Sprinkles"]
  }
];

const ingredients = [
  { id: "flour", name: "Flour", amount: "2 cups", icon: "ri-flour-bag-line" },
  { id: "sugar", name: "Sugar", amount: "1 cup", icon: "ri-sugar-line" },
  { id: "eggs", name: "Eggs", amount: "3 large", icon: "ri-egg-line" },
  { id: "butter", name: "Butter", amount: "1/2 cup", icon: "ri-butter-line" },
  { id: "milk", name: "Milk", amount: "1 cup", icon: "ri-drop-line" },
  { id: "vanilla", name: "Vanilla Extract", amount: "2 tsp", icon: "ri-test-tube-line" },
  { id: "chocolate", name: "Chocolate Chips", amount: "1 cup", icon: "ri-cookie-line" },
  { id: "cocoa", name: "Cocoa Powder", amount: "1/3 cup", icon: "ri-powder-line" },
  { id: "brownsugar", name: "Brown Sugar", amount: "1/2 cup", icon: "ri-sugar-line" },
  { id: "sprinkles", name: "Sprinkles", amount: "1/4 cup", icon: "ri-rainbow-line" },
  { id: "bakingpowder", name: "Baking Powder", amount: "2 tsp", icon: "ri-flask-line" },
  { id: "salt", name: "Salt", amount: "1/2 tsp", icon: "ri-water-percent-line" }
];

export default function GroceryArea() {
  const { 
    selectedRecipe, 
    setSelectedRecipe, 
    setCurrentStep 
  } = useBakingFlow();
  
  // When this component mounts, set the current step to 1
  React.useEffect(() => {
    setCurrentStep(1);
  }, [setCurrentStep]);
  
  // Mock query for recipes - in a real app, this would fetch from the API
  const { data: recipes = recipeOptions, isLoading: recipesLoading } = useQuery({
    queryKey: ['/api/recipes'],
    queryFn: async () => {
      // In a real app, this would be a fetch call to the API
      return recipeOptions;
    },
    enabled: true,
  });
  
  // Mock query for ingredients - in a real app, this would fetch from the API
  const { data: availableIngredients = ingredients, isLoading: ingredientsLoading } = useQuery({
    queryKey: ['/api/ingredients'],
    queryFn: async () => {
      // In a real app, this would be a fetch call to the API
      return ingredients;
    },
    enabled: true,
  });
  
  return (
    <>
      <Helmet>
        <title>Grocery Area | Childhood Bakery Café</title>
        <meta name="description" content="Select your ingredients and recipe to start your baking journey." />
      </Helmet>
      
      <ProgressIndicator 
        currentStep={1}
        stepTitle="Grocery Area"
        stepColor="#FFD700"
        prevPath="/create"
        prevArea="Create Menu"
      />
      
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-2">
            <h2 className="text-2xl font-bold text-[#8B4513] mb-6">Choose your recipe</h2>
            
            {recipesLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[1, 2, 3, 4].map((index) => (
                  <Card key={index} className="p-6 h-32 animate-pulse bg-gray-100" />
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {recipes.map((recipe) => (
                  <SelectionItem
                    key={recipe.id}
                    id={recipe.id}
                    title={recipe.name}
                    description={recipe.description}
                    selected={selectedRecipe === recipe.id}
                    onClick={() => setSelectedRecipe(recipe.id)}
                    color="#FFD700"
                  />
                ))}
              </div>
            )}
            
            <h2 className="text-2xl font-bold text-[#8B4513] my-6">Available ingredients</h2>
            
            {ingredientsLoading ? (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[1, 2, 3, 4, 5, 6, 7, 8].map((index) => (
                  <Card key={index} className="p-4 h-20 animate-pulse bg-gray-100" />
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {availableIngredients.slice(0, 12).map((ingredient) => (
                  <Card key={ingredient.id} className="p-4 flex items-center shadow-sm hover:shadow-md transition-shadow">
                    <div className="w-8 h-8 rounded-full bg-[#FFD700] flex items-center justify-center mr-3">
                      <i className={ingredient.icon} style={{ color: "white" }} />
                    </div>
                    <div>
                      <p className="font-medium">{ingredient.name}</p>
                      <p className="text-xs text-gray-500">{ingredient.amount}</p>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>
          
          <div className="md:col-span-1">
            <Card className="p-6 sticky top-24">
              <h3 className="text-xl font-bold text-[#8B4513] mb-4">Your Selection</h3>
              
              {selectedRecipe ? (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="mb-4">
                    <p className="font-bold">Recipe:</p>
                    <p>{recipes.find(r => r.id === selectedRecipe)?.name}</p>
                  </div>
                  
                  <div className="mb-6">
                    <p className="font-bold">Required ingredients:</p>
                    <ul className="list-disc list-inside text-sm">
                      {recipes.find(r => r.id === selectedRecipe)?.ingredients.map((ing, index) => (
                        <li key={index}>{ing}</li>
                      ))}
                    </ul>
                  </div>
                </motion.div>
              ) : (
                <p className="text-gray-500 italic">Choose a recipe to see the ingredients you'll need.</p>
              )}
            </Card>
          </div>
        </div>
      </div>
    </>
  );
}