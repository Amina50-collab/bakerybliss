import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import ProgressIndicator from "@/components/ProgressIndicator";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useBakingFlow } from "@/hooks/use-baking-flow";

export default function DecorationArea() {
  const [, navigate] = useLocation();
  const { 
    selectedRecipe, 
    selectedFrosting,
    selectedToppings,
    setSelectedToppings,
    customMessage,
    setCustomMessage,
    selectedFont,
    setSelectedFont,
    setCurrentStep,
  } = useBakingFlow();
  
  const { data: decorations } = useQuery({ queryKey: ['/api/decorations'] });
  
  useEffect(() => {
    setCurrentStep(4);
    
    // Redirect if no recipe or frosting selected
    if (!selectedRecipe) {
      navigate("/grocery");
    } else if (!selectedFrosting) {
      navigate("/frosting");
    }
  }, [selectedRecipe, selectedFrosting, setCurrentStep, navigate]);

  const handleToppingChange = (toppingId: string, checked: boolean) => {
    if (checked) {
      setSelectedToppings([...selectedToppings, toppingId]);
    } else {
      setSelectedToppings(selectedToppings.filter(id => id !== toppingId));
    }
  };

  const handleComplete = () => {
    navigate("/final");
  };

  const fontOptions = [
    { id: "script", name: "Script", description: "Elegant cursive style" },
    { id: "block", name: "Block", description: "Bold, easy to read letters" },
    { id: "fun", name: "Fun", description: "Playful, whimsical style" },
    { id: "formal", name: "Formal", description: "Classic, traditional look" }
  ];

  return (
    <div className="container mx-auto">
      <ProgressIndicator 
        currentStep={4} 
        stepTitle="Decoration" 
        stepColor="#6A5ACD"
        prevPath="/frosting"
        prevArea="frosting"
      />
      
      <p className="text-center text-gray-600 mb-8">Add the final touches to make your creation special!</p>
      
      <section className="mb-10">
        <Card className="bg-white rounded-xl shadow-md">
          <CardContent className="p-6">
            <h3 className="font-display text-xl mb-6 text-[#8B4513]">Decorating Options</h3>
            
            <div className="flex flex-col md:flex-row gap-8 mb-8">
              <div className="w-full md:w-1/2">
                <h4 className="font-bold mb-4 text-[#6A5ACD]">Add Toppings</h4>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-8">
                  {decorations?.map((decoration) => (
                    <div key={decoration.id} className="flex items-center space-x-2 p-3 hover:bg-[#FFF8E1] hover:bg-opacity-30 rounded cursor-pointer border border-gray-100 transition-all">
                      <Checkbox 
                        id={`decoration-${decoration.id}`} 
                        checked={selectedToppings.includes(decoration.id.toString())}
                        onCheckedChange={(checked) => handleToppingChange(decoration.id.toString(), !!checked)} 
                      />
                      <Label 
                        htmlFor={`decoration-${decoration.id}`}
                        className="flex-1 cursor-pointer"
                      >
                        {decoration.name}
                      </Label>
                    </div>
                  ))}
                </div>
                
                <h4 className="font-bold mb-4 text-[#6A5ACD]">Custom Message</h4>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="custom-message">Message Text (20 char max)</Label>
                    <Input 
                      id="custom-message" 
                      value={customMessage}
                      onChange={(e) => setCustomMessage(e.target.value.slice(0, 20))}
                      placeholder="Happy Birthday!"
                      className="mt-1"
                    />
                  </div>
                  
                  <div>
                    <Label className="mb-2 block">Font Style</Label>
                    <RadioGroup 
                      value={selectedFont} 
                      onValueChange={setSelectedFont}
                      className="grid grid-cols-2 gap-2"
                    >
                      {fontOptions.map((font) => (
                        <div key={font.id} className="flex items-center space-x-2 border border-gray-100 p-2 rounded cursor-pointer hover:bg-[#FFF8E1] hover:bg-opacity-30">
                          <RadioGroupItem value={font.id} id={`font-${font.id}`} />
                          <Label htmlFor={`font-${font.id}`} className="cursor-pointer">
                            <span className="block font-medium">{font.name}</span>
                            <span className="text-xs text-gray-500">{font.description}</span>
                          </Label>
                        </div>
                      ))}
                    </RadioGroup>
                  </div>
                </div>
              </div>
              
              <div className="w-full md:w-1/2">
                <div className="h-80 w-full bg-[#6A5ACD] bg-opacity-20 rounded-lg flex items-center justify-center mb-4 relative">
                  <div className="text-center p-4">
                    <div className="w-40 h-40 rounded-full mx-auto bg-yellow-100 flex items-center justify-center relative">
                      {/* Display selected toppings */}
                      {selectedToppings.length > 0 && (
                        <div className="absolute inset-0 flex flex-wrap justify-center items-center p-2">
                          {selectedToppings.map((id) => {
                            const decoration = decorations?.find(d => d.id.toString() === id);
                            return (
                              <span key={id} className="m-1 text-sm px-2 py-1 bg-white rounded-full shadow-sm">
                                {decoration?.name || id}
                              </span>
                            );
                          })}
                        </div>
                      )}
                    </div>
                    
                    {/* Display custom message */}
                    {customMessage && (
                      <div className={`mt-4 p-2 ${
                        selectedFont === 'script' ? 'font-pacifico' : 
                        selectedFont === 'block' ? 'font-bold uppercase' :
                        selectedFont === 'fun' ? 'font-bold text-[#6A5ACD]' :
                        'font-serif'
                      }`}>
                        {customMessage}
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="border p-4 rounded-lg shadow-sm">
                  <h4 className="font-bold mb-2 text-[#8B4513]">Decoration Tips</h4>
                  <ul className="list-disc pl-5 space-y-2 text-sm text-gray-700">
                    <li>Less is sometimes more - don't overcrowd your creation</li>
                    <li>Consider color combinations when choosing decorations</li>
                    <li>Edible flowers make beautiful, natural decorations</li>
                    <li>Add decorations just before serving for the freshest look</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="border-t border-gray-200 pt-6 flex justify-end">
              <Button
                className="bg-[#6A5ACD] hover:bg-[#6A5ACD]/90 text-white font-bold"
                onClick={handleComplete}
              >
                Complete My Creation
                <i className="ri-check-line ml-2"></i>
              </Button>
            </div>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}