import React, { useState } from 'react';
import { useRoute, Link } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Calendar, Clock, ChevronLeft, Users, MessageSquare, Share2, Heart } from 'lucide-react';
import { format } from 'date-fns';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import type { Event, Recipe, EventParticipant, InsertEventParticipant } from '@shared/schema';

const EventDetail = () => {
  const [match, params] = useRoute('/events/:id');
  const eventId = parseInt(params?.id || '0');
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [memoryStory, setMemoryStory] = useState('');
  const [showJoinDialog, setShowJoinDialog] = useState(false);

  // Fetch event details
  const { data: event, isLoading: isLoadingEvent } = useQuery<Event>({
    queryKey: [`/api/events/${eventId}`],
    enabled: !!eventId,
  });

  // Fetch event recipes
  const { data: eventRecipes, isLoading: isLoadingRecipes } = useQuery<Recipe[]>({
    queryKey: [`/api/events/${eventId}/recipes`],
    enabled: !!eventId,
  });

  // Fetch event participants
  const { data: participants, isLoading: isLoadingParticipants } = useQuery<EventParticipant[]>({
    queryKey: [`/api/events/${eventId}/participants`],
    enabled: !!eventId,
  });

  // Join event mutation
  const joinEventMutation = useMutation({
    mutationFn: (data: InsertEventParticipant) => 
      apiRequest(`/api/events/${eventId}/participants`, 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/events/${eventId}/participants`] });
      toast({
        title: "Successfully joined the event!",
        description: "Your memory story has been shared with the community.",
      });
      setShowJoinDialog(false);
      setMemoryStory('');
    },
    onError: (error) => {
      toast({
        title: "Failed to join event",
        description: "Please try again later.",
        variant: "destructive",
      });
    },
  });

  const handleJoinEvent = () => {
    // For demo purposes, we're using a hardcoded user ID 1
    // In a real app, this would come from authentication
    const userId = 1;
    
    joinEventMutation.mutate({
      userId,
      eventId,
      memoryStory,
    });
  };

  if (isLoadingEvent) {
    return (
      <div className="container mx-auto py-12">
        <div className="flex flex-col items-center justify-center min-h-[400px]">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
          <p className="mt-4 text-lg text-muted-foreground">Loading event details...</p>
        </div>
      </div>
    );
  }

  if (!event) {
    return (
      <div className="container mx-auto py-12">
        <div className="text-center py-12">
          <h2 className="text-2xl font-bold mb-2">Event Not Found</h2>
          <p className="mb-6 text-muted-foreground">The event you're looking for doesn't exist or has been removed.</p>
          <Button asChild>
            <Link href="/events">Back to Events</Link>
          </Button>
        </div>
      </div>
    );
  }

  // Format dates
  const startDate = new Date(event.startDate);
  const endDate = new Date(event.endDate);
  const dateRange = `${format(startDate, 'MMM d')} - ${format(endDate, 'MMM d, yyyy')}`;
  const daysRemaining = Math.ceil((endDate.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
  const isActive = new Date() >= startDate && new Date() <= endDate;

  return (
    <div className="container mx-auto py-12">
      <div className="flex items-center mb-8">
        <Button variant="ghost" size="sm" asChild className="mr-4">
          <Link href="/events">
            <ChevronLeft className="mr-1 h-4 w-4" />
            Back to Events
          </Link>
        </Button>
        <Badge variant={isActive ? "default" : "secondary"} className="ml-auto">
          {isActive ? 'Active Event' : 'Upcoming Event'}
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div>
            <h1 className="text-3xl font-bold tracking-tight mb-3">{event.title}</h1>
            <p className="text-muted-foreground text-lg mb-6">{event.description}</p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
              <div className="flex items-center">
                <Calendar className="mr-2 h-5 w-5 text-muted-foreground" />
                <span>{dateRange}</span>
              </div>
              <div className="flex items-center">
                <Clock className="mr-2 h-5 w-5 text-muted-foreground" />
                <span>{daysRemaining} {daysRemaining === 1 ? 'day' : 'days'} remaining</span>
              </div>
            </div>
            
            <div className="rounded-lg overflow-hidden bg-muted/20 p-6 border">
              <h3 className="text-xl font-medium mb-3">Childhood Memory Theme</h3>
              <p>{event.memoryDescription}</p>
            </div>
          </div>

          {isLoadingRecipes ? (
            <div className="py-8 text-center">Loading featured recipes...</div>
          ) : (
            <div>
              <h2 className="text-2xl font-bold mb-4">Featured Recipes</h2>
              {eventRecipes && eventRecipes.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {eventRecipes.map((recipe) => (
                    <EventRecipeCard key={recipe.id} recipe={recipe} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 bg-muted/10 rounded-lg border">
                  <p>No featured recipes for this event yet.</p>
                </div>
              )}
            </div>
          )}

          {isLoadingParticipants ? (
            <div className="py-8 text-center">Loading participants...</div>
          ) : (
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-bold">Memory Stories</h2>
                <div className="flex items-center">
                  <Users className="mr-2 h-5 w-5 text-muted-foreground" />
                  <span>{participants?.length || 0} participants</span>
                </div>
              </div>
              
              {participants && participants.length > 0 ? (
                <div className="space-y-4">
                  {participants
                    .filter(p => p.memoryStory)
                    .map((participant) => (
                      <Card key={participant.id}>
                        <CardHeader className="pb-3">
                          <div className="flex items-center">
                            <Avatar className="h-8 w-8 mr-2">
                              <AvatarFallback>U{participant.userId}</AvatarFallback>
                            </Avatar>
                            <div>
                              <CardTitle className="text-base">User {participant.userId}</CardTitle>
                              <CardDescription className="text-xs">
                                Joined on {participant.joinedAt ? format(new Date(participant.joinedAt), 'MMM d, yyyy') : 'unknown date'}
                              </CardDescription>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm">{participant.memoryStory}</p>
                        </CardContent>
                      </Card>
                    ))}
                </div>
              ) : (
                <div className="text-center py-8 bg-muted/10 rounded-lg border">
                  <p>No memory stories shared yet. Be the first to share yours!</p>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="lg:col-span-1">
          <div className="sticky top-20">
            <Card>
              <CardHeader>
                <CardTitle>Join This Event</CardTitle>
                <CardDescription>
                  Share your childhood memories and create special treats inspired by this theme.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="rounded-lg overflow-hidden">
                  {event.imageUrl ? (
                    <img 
                      src={event.imageUrl} 
                      alt={event.title} 
                      className="w-full h-40 object-cover" 
                    />
                  ) : (
                    <div className="w-full h-40 bg-muted flex items-center justify-center">
                      <span className="text-2xl font-bold text-muted-foreground">{event.theme}</span>
                    </div>
                  )}
                </div>
                
                <div className="pt-2">
                  <h3 className="font-medium mb-2">Theme: {event.theme}</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Create a special treat inspired by your childhood memories related to this theme.
                  </p>
                </div>
              </CardContent>
              <CardFooter className="flex flex-col space-y-3">
                <Button onClick={() => setShowJoinDialog(true)} className="w-full" size="lg">
                  Share Your Memory
                </Button>
                <Button variant="outline" className="w-full" asChild>
                  <Link href="/create">Start Baking Now</Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>

      <Dialog open={showJoinDialog} onOpenChange={setShowJoinDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Share Your Memory</DialogTitle>
            <DialogDescription>
              Tell us about your childhood memory related to {event.theme}. What makes it special to you?
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Textarea 
              placeholder="Share your memory story here..." 
              className="min-h-[150px]"
              value={memoryStory}
              onChange={(e) => setMemoryStory(e.target.value)}
            />
          </div>
          <DialogFooter>
            <Button 
              onClick={handleJoinEvent} 
              disabled={!memoryStory.trim() || joinEventMutation.isPending}
            >
              {joinEventMutation.isPending ? "Sharing..." : "Share Memory"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

interface EventRecipeCardProps {
  recipe: Recipe;
}

const EventRecipeCard = ({ recipe }: EventRecipeCardProps) => {
  return (
    <Card className="overflow-hidden flex flex-col h-full hover:shadow-sm transition-shadow">
      <div className="aspect-[4/3] bg-muted relative overflow-hidden">
        {recipe.imageUrl ? (
          <img 
            src={recipe.imageUrl} 
            alt={recipe.name} 
            className="object-cover w-full h-full"
          />
        ) : (
          <div className="flex items-center justify-center h-full bg-primary/10">
            <span className="text-xl font-medium text-primary/60">{recipe.type}</span>
          </div>
        )}
        <Badge className="absolute top-2 right-2">{recipe.type}</Badge>
      </div>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">{recipe.name}</CardTitle>
        <CardDescription className="line-clamp-2">{recipe.description}</CardDescription>
      </CardHeader>
      <CardFooter className="pt-0 mt-auto">
        <Button variant="outline" className="w-full" size="sm" asChild>
          <Link href={`/recipes/${recipe.id}`}>View Recipe</Link>
        </Button>
      </CardFooter>
    </Card>
  );
};

export default EventDetail;