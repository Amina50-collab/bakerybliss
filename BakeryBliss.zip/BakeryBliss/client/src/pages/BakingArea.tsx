import { useEffect } from "react";
import { useLocation } from "wouter";
import ProgressIndicator from "@/components/ProgressIndicator";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { SelectionItem } from "@/components/ui/selection-item";
import { useBakingFlow } from "@/hooks/use-baking-flow";

export default function BakingArea() {
  const [, navigate] = useLocation();
  const { selectedRecipe, currentStep, setCurrentStep } = useBakingFlow();
  
  useEffect(() => {
    setCurrentStep(2);
    
    // Redirect if no recipe selected
    if (!selectedRecipe) {
      navigate("/grocery");
    }
  }, [selectedRecipe, setCurrentStep, navigate]);

  const handleContinue = () => {
    navigate("/frosting");
  };

  const bakingInstructions = [
    "Preheat oven to 350°F (175°C)",
    "Mix all dry ingredients in a large bowl",
    "In a separate bowl, cream together butter and sugar",
    "Add eggs one at a time, then vanilla",
    "Gradually add dry ingredients to wet ingredients",
    "Pour batter into prepared pan",
    "Bake for 25-30 minutes or until golden brown"
  ];

  return (
    <div className="container mx-auto">
      <ProgressIndicator 
        currentStep={2} 
        stepTitle="Baking" 
        stepColor="#D2B48C"
        prevPath="/grocery"
        prevArea="grocery"
      />
      
      <p className="text-center text-gray-600 mb-8">Time to bake your creation!</p>
      
      <section className="mb-10">
        <Card className="bg-white rounded-xl shadow-md">
          <CardContent className="p-6">
            <h3 className="font-display text-xl mb-6 text-[#8B4513]">Baking Instructions</h3>
            
            <div className="flex flex-col md:flex-row gap-8 mb-8">
              <div className="w-full md:w-1/2">
                <div className="bg-[#FFF8E1] bg-opacity-30 p-4 rounded-lg mb-6">
                  <h4 className="font-bold mb-4">Step-by-Step Instructions</h4>
                  <ol className="list-decimal pl-5 space-y-2">
                    {bakingInstructions.map((instruction, index) => (
                      <li key={index} className="text-gray-700">{instruction}</li>
                    ))}
                  </ol>
                </div>
                
                <div className="bg-[#FFF8E1] bg-opacity-30 p-4 rounded-lg">
                  <h4 className="font-bold mb-4">Baking Timer</h4>
                  <div className="flex items-center justify-center p-3 bg-white rounded-lg mb-4">
                    <span className="text-3xl font-bold text-[#8B4513]">00:00</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Button 
                      className="bg-[#93C572] text-white py-2 rounded font-bold"
                    >
                      Start Timer
                    </Button>
                    <Button 
                      className="bg-[#C41E3A] text-white py-2 rounded font-bold"
                    >
                      Reset Timer
                    </Button>
                  </div>
                </div>
              </div>
              
              <div className="w-full md:w-1/2">
                <div className="h-64 w-full bg-[#D2B48C] bg-opacity-20 rounded-lg flex items-center justify-center mb-4">
                  <div className="text-center">
                    <i className="ri-bowl-line text-5xl text-[#D2B48C] mb-2"></i>
                    <p className="text-[#8B4513] font-medium">Your treat is baking...</p>
                  </div>
                </div>
                
                <div className="border p-4 rounded-lg shadow-sm">
                  <h4 className="font-bold mb-2 text-[#8B4513]">Baking Tips</h4>
                  <ul className="list-disc pl-5 space-y-2 text-sm text-gray-700">
                    <li>Make sure all ingredients are at room temperature for even mixing</li>
                    <li>Don't overmix the batter - it can make your cake dense</li>
                    <li>Check for doneness by inserting a toothpick into the center</li>
                    <li>Let your creation cool completely before frosting</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="border-t border-gray-200 pt-6 flex justify-end">
              <Button
                className="bg-[#D2B48C] hover:bg-[#D2B48C]/90 text-white font-bold"
                onClick={handleContinue}
              >
                Continue to Frosting
                <i className="ri-arrow-right-line ml-2"></i>
              </Button>
            </div>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}