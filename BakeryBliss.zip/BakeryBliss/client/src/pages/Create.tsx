import { Helmet } from "react-helmet";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { useBakingFlow } from "@/hooks/use-baking-flow";
import { Card } from "@/components/ui/card";

const Create = () => {
  const { reset } = useBakingFlow();
  
  // Reset the baking flow when entering the create page
  reset();
  
  const zones = [
    {
      id: "grocery",
      title: "Grocery Zone",
      description: "Select your ingredients and recipe to get started",
      icon: "ri-shopping-basket-2-line",
      color: "#FFD700",
      path: "/grocery",
      number: 1
    },
    {
      id: "baking",
      title: "Baking Zone",
      description: "Follow instructions to bake your creation",
      icon: "ri-bowl-line",
      color: "#D2B48C",
      path: "/baking",
      number: 2
    },
    {
      id: "frosting",
      title: "Frosting Zone",
      description: "Add delicious frosting in your favorite flavor",
      icon: "ri-paint-brush-line",
      color: "#FFB6C1",
      path: "/frosting",
      number: 3
    },
    {
      id: "decoration",
      title: "Decoration Zone",
      description: "Add the final touches to make it special",
      icon: "ri-magic-line",
      color: "#6A5ACD",
      path: "/decoration",
      number: 4
    }
  ];
  
  return (
    <>
      <Helmet>
        <title>Create Your Baked Good | Childhood Bakery Café</title>
        <meta name="description" content="Create your own personalized baked good with our interactive baking process. Choose ingredients, customize frostings, and add decorations." />
      </Helmet>
      
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <h1 className="font-pacifico text-4xl text-center text-[#8B4513] mb-4">Create Your Dream Treat</h1>
          <p className="text-center text-gray-700 mb-8 max-w-2xl mx-auto">
            Let your imagination run wild as you design and customize your own delicious creation.
          </p>
          <p className="text-center italic text-[#8B4513] font-medium mb-12">"Turn your childhood into reality"</p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            {zones.map((zone, index) => (
              <motion.div
                key={zone.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <Link href={zone.path}>
                  <Card className="h-full p-6 flex flex-col items-center text-center cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-1" style={{ borderColor: zone.color, borderWidth: '2px' }}>
                    <div className="w-16 h-16 rounded-full flex items-center justify-center mb-4" style={{ backgroundColor: zone.color }}>
                      <span className="text-white font-bold text-2xl">{zone.number}</span>
                    </div>
                    <i className={`${zone.icon} text-4xl mb-4`} style={{ color: zone.color }}></i>
                    <h3 className="font-bold text-xl mb-2 text-[#8B4513]">{zone.title}</h3>
                    <p className="text-gray-600 text-sm">{zone.description}</p>
                  </Card>
                </Link>
              </motion.div>
            ))}
          </div>
          
          <div className="mt-12 text-center">
            <p className="text-gray-500">Start in the Grocery Zone and make your way through all four zones to complete your creation!</p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Create;
