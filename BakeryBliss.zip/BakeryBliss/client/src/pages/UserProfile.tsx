import React, { useState } from 'react';
import { useRoute, Link } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Edit, Award, Heart, Cake, Calendar, ChevronLeft, SquarePen } from 'lucide-react';
import { format } from 'date-fns';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import type { User, UserProfile, BakedItem, Favorite } from '@shared/schema';

const ProfilePage = () => {
  const [match, params] = useRoute('/profile/:userId');
  const userId = parseInt(params?.userId || '1'); // Default to userId 1 for demo purposes
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch user and profile data
  const { data: user, isLoading: isLoadingUser } = useQuery<User>({
    queryKey: [`/api/users/${userId}`],
  });

  const { data: profile, isLoading: isLoadingProfile } = useQuery<UserProfile>({
    queryKey: [`/api/users/${userId}/profile`],
    enabled: !!userId,
  });

  // Fetch user's baked items
  const { data: bakedItems, isLoading: isLoadingBakedItems } = useQuery<BakedItem[]>({
    queryKey: [`/api/users/${userId}/baked-items`],
    enabled: !!userId,
  });

  // Fetch user's favorites
  const { data: favorites, isLoading: isLoadingFavorites } = useQuery<BakedItem[]>({
    queryKey: [`/api/users/${userId}/favorites`],
    enabled: !!userId,
  });

  // Remove from favorites mutation
  const removeFavoriteMutation = useMutation({
    mutationFn: (bakedItemId: number) => 
      apiRequest(`/api/users/${userId}/favorites/${bakedItemId}`, {
        method: 'DELETE',
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}/favorites`] });
      toast({
        title: "Removed from favorites",
        description: "The item has been removed from your favorites.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to remove favorite",
        description: "Please try again later.",
        variant: "destructive",
      });
    },
  });

  const handleRemoveFavorite = (bakedItemId: number) => {
    removeFavoriteMutation.mutate(bakedItemId);
  };

  const isLoading = isLoadingUser || isLoadingProfile;

  if (isLoading) {
    return (
      <div className="container mx-auto py-12">
        <div className="flex flex-col items-center justify-center min-h-[400px]">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
          <p className="mt-4 text-lg text-muted-foreground">Loading profile...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="container mx-auto py-12">
        <div className="text-center py-12">
          <h2 className="text-2xl font-bold mb-2">User Not Found</h2>
          <p className="mb-6 text-muted-foreground">The user profile you're looking for doesn't exist.</p>
          <Button asChild>
            <Link href="/">Return Home</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-12">
      <Button variant="ghost" size="sm" asChild className="mb-8">
        <Link href="/">
          <ChevronLeft className="mr-1 h-4 w-4" />
          Back to Home
        </Link>
      </Button>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-1">
          <div className="sticky top-20 space-y-6">
            <Card>
              <CardHeader className="text-center pb-2">
                <div className="flex justify-center mb-4">
                  <Avatar className="h-24 w-24">
                    {user.avatarUrl ? (
                      <AvatarImage src={user.avatarUrl} alt={user.name || user.username} />
                    ) : (
                      <AvatarFallback className="text-2xl">
                        {user.name?.[0] || user.username[0]}
                      </AvatarFallback>
                    )}
                  </Avatar>
                </div>
                <CardTitle className="text-xl font-bold">{user.name || user.username}</CardTitle>
                <CardDescription>@{user.username}</CardDescription>
              </CardHeader>
              <CardContent className="pt-2">
                {user.bio && (
                  <div className="mb-4">
                    <p className="text-sm">{user.bio}</p>
                  </div>
                )}
                
                <Separator className="my-4" />
                
                {profile && (
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-sm font-medium mb-1">Baking Level</h3>
                      <Badge variant="secondary" className="font-normal">
                        {profile.bakingLevel?.charAt(0).toUpperCase() + profile.bakingLevel?.slice(1) || 'Beginner'}
                      </Badge>
                    </div>
                    
                    <div>
                      <h3 className="text-sm font-medium mb-1">Baking Streak</h3>
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-1 text-muted-foreground" />
                        <span>{profile.bakingStreak || 0} days</span>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-sm font-medium mb-1">Achievements</h3>
                      <div className="flex flex-wrap gap-1">
                        {profile.achievements?.length > 0 ? (
                          (profile.achievements as string[]).map((achievement, index) => (
                            <Badge key={index} variant="outline" className="font-normal">
                              {achievement.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                            </Badge>
                          ))
                        ) : (
                          <span className="text-sm text-muted-foreground">No achievements yet</span>
                        )}
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-sm font-medium mb-1">Favorite Flavors</h3>
                      <div className="flex flex-wrap gap-1">
                        {profile.favoriteFlavors?.length > 0 ? (
                          (profile.favoriteFlavors as string[]).map((flavor, index) => (
                            <Badge key={index} variant="secondary" className="font-normal">
                              {flavor.charAt(0).toUpperCase() + flavor.slice(1)}
                            </Badge>
                          ))
                        ) : (
                          <span className="text-sm text-muted-foreground">No favorite flavors yet</span>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" asChild>
                  <Link href={`/profile/${userId}/edit`}>
                    <Edit className="mr-2 h-4 w-4" />
                    Edit Profile
                  </Link>
                </Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" className="w-full justify-start" asChild>
                  <Link href="/create">
                    <Cake className="mr-2 h-4 w-4" />
                    Create New Bake
                  </Link>
                </Button>
                <Button variant="outline" className="w-full justify-start" asChild>
                  <Link href="/events">
                    <Calendar className="mr-2 h-4 w-4" />
                    Browse Events
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="lg:col-span-3">
          <Tabs defaultValue="creations">
            <TabsList className="mb-6">
              <TabsTrigger value="creations">
                <Cake className="mr-2 h-4 w-4" />
                My Creations
              </TabsTrigger>
              <TabsTrigger value="favorites">
                <Heart className="mr-2 h-4 w-4" />
                Favorites
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="creations">
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold">My Baked Creations</h2>
                  <Button asChild>
                    <Link href="/create">
                      <SquarePen className="mr-2 h-4 w-4" />
                      Create New
                    </Link>
                  </Button>
                </div>
                
                {isLoadingBakedItems ? (
                  <div className="text-center py-12">
                    <p className="text-muted-foreground">Loading creations...</p>
                  </div>
                ) : (
                  <>
                    {bakedItems && bakedItems.length > 0 ? (
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                        {bakedItems.map((item) => (
                          <BakedItemCard key={item.id} item={item} />
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-12 bg-muted/10 rounded-lg border">
                        <h3 className="font-semibold mb-2">No creations yet</h3>
                        <p className="text-muted-foreground mb-6">Start baking to create your collection!</p>
                        <Button asChild>
                          <Link href="/create">Start Baking Now</Link>
                        </Button>
                      </div>
                    )}
                  </>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="favorites">
              <div className="space-y-6">
                <h2 className="text-2xl font-bold">My Favorite Creations</h2>
                
                {isLoadingFavorites ? (
                  <div className="text-center py-12">
                    <p className="text-muted-foreground">Loading favorites...</p>
                  </div>
                ) : (
                  <>
                    {favorites && favorites.length > 0 ? (
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                        {favorites.map((item) => (
                          <FavoriteItemCard 
                            key={item.id} 
                            item={item} 
                            onRemove={() => handleRemoveFavorite(item.id)}
                          />
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-12 bg-muted/10 rounded-lg border">
                        <h3 className="font-semibold mb-2">No favorites yet</h3>
                        <p className="text-muted-foreground mb-6">Browse the gallery to discover inspiring creations!</p>
                        <Button asChild>
                          <Link href="/gallery">Browse Gallery</Link>
                        </Button>
                      </div>
                    )}
                  </>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

interface BakedItemCardProps {
  item: BakedItem;
}

const BakedItemCard = ({ item }: BakedItemCardProps) => {
  return (
    <Card className="overflow-hidden flex flex-col h-full hover:shadow-sm transition-shadow">
      <div className="aspect-square bg-muted relative overflow-hidden">
        {item.imageUrl ? (
          <img 
            src={item.imageUrl} 
            alt={item.name} 
            className="object-cover w-full h-full"
          />
        ) : (
          <div className="flex items-center justify-center h-full bg-primary/10">
            <span className="text-xl font-medium text-primary/60">{item.type}</span>
          </div>
        )}
        <Badge className="absolute top-2 right-2">
          {item.type.charAt(0).toUpperCase() + item.type.slice(1)}
        </Badge>
      </div>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">{item.name}</CardTitle>
        {item.customMessage && (
          <CardDescription className="line-clamp-1">{item.customMessage}</CardDescription>
        )}
      </CardHeader>
      <CardFooter className="pt-0 mt-auto">
        <Button variant="default" className="w-full" asChild>
          <Link href={`/baked-items/${item.id}`}>View Creation</Link>
        </Button>
      </CardFooter>
    </Card>
  );
};

interface FavoriteItemCardProps {
  item: BakedItem;
  onRemove: () => void;
}

const FavoriteItemCard = ({ item, onRemove }: FavoriteItemCardProps) => {
  return (
    <Card className="overflow-hidden flex flex-col h-full hover:shadow-sm transition-shadow relative group">
      <div className="absolute top-2 right-2 z-10">
        <Button 
          variant="ghost" 
          size="icon" 
          className="h-8 w-8 rounded-full bg-background/80 opacity-0 group-hover:opacity-100 transition-opacity"
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            onRemove();
          }}
        >
          <Heart className="h-4 w-4 fill-current text-destructive" />
        </Button>
      </div>
      <div className="aspect-square bg-muted relative overflow-hidden">
        {item.imageUrl ? (
          <img 
            src={item.imageUrl} 
            alt={item.name} 
            className="object-cover w-full h-full"
          />
        ) : (
          <div className="flex items-center justify-center h-full bg-primary/10">
            <span className="text-xl font-medium text-primary/60">{item.type}</span>
          </div>
        )}
        <Badge className="absolute top-2 left-2">
          {item.type.charAt(0).toUpperCase() + item.type.slice(1)}
        </Badge>
      </div>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">{item.name}</CardTitle>
        {item.customMessage && (
          <CardDescription className="line-clamp-1">{item.customMessage}</CardDescription>
        )}
      </CardHeader>
      <CardFooter className="pt-0 mt-auto">
        <Button variant="secondary" className="w-full" asChild>
          <Link href={`/baked-items/${item.id}`}>View Creation</Link>
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ProfilePage;