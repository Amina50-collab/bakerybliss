import { useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import ProgressIndicator from "@/components/ProgressIndicator";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { SelectionItem } from "@/components/ui/selection-item";
import { useBakingFlow } from "@/hooks/use-baking-flow";

export default function FrostingArea() {
  const [, navigate] = useLocation();
  const { 
    selectedRecipe, 
    selectedFrosting,
    setSelectedFrosting,
    selectedFrostingStyle,
    setSelectedFrostingStyle,
    setCurrentStep 
  } = useBakingFlow();
  
  const { data: frostings } = useQuery({ queryKey: ['/api/frostings'] });
  
  useEffect(() => {
    setCurrentStep(3);
    
    // Redirect if no recipe selected
    if (!selectedRecipe) {
      navigate("/grocery");
    }
  }, [selectedRecipe, setCurrentStep, navigate]);

  const handleContinue = () => {
    if (!selectedFrosting) return;
    navigate("/decoration");
  };

  const frostingStyles = [
    { id: "smooth", name: "Smooth & Even", description: "Classic look with a perfectly smooth surface" },
    { id: "textured", name: "Textured Waves", description: "Beautiful waves and patterns for visual interest" },
    { id: "rustic", name: "Rustic Style", description: "Casual, homemade look with rough texture" },
    { id: "drip", name: "Drip Effect", description: "Modern style with frosting dripping down the sides" }
  ];

  return (
    <div className="container mx-auto">
      <ProgressIndicator 
        currentStep={3} 
        stepTitle="Frosting" 
        stepColor="#FFB6C1"
        prevPath="/baking"
        prevArea="baking"
      />
      
      <p className="text-center text-gray-600 mb-8">Time to add delicious frosting to your creation!</p>
      
      <section className="mb-10">
        <Card className="bg-white rounded-xl shadow-md">
          <CardContent className="p-6">
            <h3 className="font-display text-xl mb-6 text-[#8B4513]">Choose Your Frosting</h3>
            
            <div className="flex flex-col md:flex-row gap-8 mb-8">
              <div className="w-full md:w-1/2">
                <h4 className="font-bold mb-4 text-[#FFB6C1]">Frosting Flavor</h4>
                
                <RadioGroup 
                  value={selectedFrosting || ""} 
                  onValueChange={setSelectedFrosting}
                  className="space-y-3"
                >
                  {frostings?.map((frosting) => (
                    <div key={frosting.id} className="flex items-center space-x-2 p-2 hover:bg-[#FFF8E1] hover:bg-opacity-30 rounded cursor-pointer">
                      <RadioGroupItem value={frosting.id.toString()} id={`frosting-${frosting.id}`} />
                      <Label 
                        htmlFor={`frosting-${frosting.id}`}
                        className="flex-1 cursor-pointer flex items-center"
                      >
                        <div 
                          className="w-4 h-4 rounded-full mr-2" 
                          style={{ backgroundColor: frosting.color }}
                        ></div>
                        {frosting.name}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
                
                <h4 className="font-bold mb-4 mt-8 text-[#FFB6C1]">Frosting Style</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {frostingStyles.map((style) => (
                    <SelectionItem
                      key={style.id}
                      id={style.id}
                      title={style.name}
                      description={style.description}
                      selected={selectedFrostingStyle === style.id}
                      onClick={() => setSelectedFrostingStyle(style.id)}
                      color="#FFB6C1"
                      size="small"
                    />
                  ))}
                </div>
              </div>
              
              <div className="w-full md:w-1/2">
                <div className="h-64 w-full bg-[#FFB6C1] bg-opacity-20 rounded-lg flex items-center justify-center mb-4">
                  {selectedFrosting ? (
                    <div className="text-center">
                      <div className="w-32 h-32 rounded-full mx-auto mb-4" style={{ 
                        backgroundColor: frostings?.find(f => f.id.toString() === selectedFrosting)?.color || "#FFF" 
                      }}></div>
                      <p className="text-[#8B4513] font-medium">
                        {frostings?.find(f => f.id.toString() === selectedFrosting)?.name || "Selected Frosting"}
                      </p>
                      {selectedFrostingStyle && (
                        <p className="text-gray-500 text-sm">
                          Style: {frostingStyles.find(s => s.id === selectedFrostingStyle)?.name}
                        </p>
                      )}
                    </div>
                  ) : (
                    <div className="text-center">
                      <i className="ri-paint-brush-line text-5xl text-[#FFB6C1] mb-2"></i>
                      <p className="text-[#8B4513] font-medium">Select a frosting to preview</p>
                    </div>
                  )}
                </div>
                
                <div className="border p-4 rounded-lg shadow-sm">
                  <h4 className="font-bold mb-2 text-[#8B4513]">Frosting Tips</h4>
                  <ul className="list-disc pl-5 space-y-2 text-sm text-gray-700">
                    <li>Make sure your baked item is completely cool before frosting</li>
                    <li>For a smooth finish, use a bench scraper or offset spatula</li>
                    <li>Create textures by using different tools like combs or spoons</li>
                    <li>Keep your frosting at room temperature for easier spreading</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="border-t border-gray-200 pt-6 flex justify-end">
              <Button
                className="bg-[#FFB6C1] hover:bg-[#FFB6C1]/90 text-white font-bold"
                onClick={handleContinue}
                disabled={!selectedFrosting}
              >
                Continue to Decoration
                <i className="ri-arrow-right-line ml-2"></i>
              </Button>
            </div>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}