import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Calendar, Clock, Users, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import type { Event } from '@shared/schema';

const ThemedEvents = () => {
  const { data: events, isLoading } = useQuery<Event[]>({
    queryKey: ['/api/events/active'],
  });

  if (isLoading) {
    return (
      <div className="container mx-auto py-12">
        <div className="flex flex-col items-center justify-center min-h-[400px]">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
          <p className="mt-4 text-lg text-muted-foreground">Loading events...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-12">
      <div className="space-y-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold tracking-tight mb-4">Childhood Memory Themed Events</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Join our special events inspired by cherished childhood memories. Create unique treats and share your own nostalgic stories!
          </p>
        </div>

        {events && events.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {events.map((event) => (
              <EventCard key={event.id} event={event} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 border rounded-lg bg-muted/20">
            <h3 className="text-xl font-medium mb-2">No active events</h3>
            <p className="text-muted-foreground">Check back soon for upcoming events!</p>
          </div>
        )}
        
        <div className="bg-muted/30 rounded-lg p-8 mt-12">
          <h2 className="text-2xl font-bold mb-4">Create Your Childhood Memory</h2>
          <p className="mb-6">
            Our themed events celebrate the joy and nostalgia of childhood. Share your own memorable stories and creations with our community!
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Button asChild>
              <Link href="/create">Start Baking Now</Link>
            </Button>
            <Button variant="outline" asChild>
              <Link href="/gallery">View Gallery</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

interface EventCardProps {
  event: Event;
}

const EventCard = ({ event }: EventCardProps) => {
  // Format dates for display
  const startDate = new Date(event.startDate);
  const endDate = new Date(event.endDate);
  
  const isOngoing = new Date() >= startDate && new Date() <= endDate;
  const dateRange = `${format(startDate, 'MMM d')} - ${format(endDate, 'MMM d, yyyy')}`;
  
  // Calculate days remaining
  const daysRemaining = Math.ceil((endDate.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
  
  return (
    <Card className="overflow-hidden flex flex-col h-full transition-all hover:shadow-md">
      <div className="aspect-video relative bg-muted overflow-hidden">
        {event.imageUrl ? (
          <img 
            src={event.imageUrl} 
            alt={event.title} 
            className="object-cover w-full h-full"
          />
        ) : (
          <div className="flex items-center justify-center h-full bg-primary/10">
            <span className="text-2xl font-bold text-primary/50">{event.theme}</span>
          </div>
        )}
        <Badge className="absolute top-4 right-4" variant={isOngoing ? "default" : "secondary"}>
          {isOngoing ? 'Ongoing' : 'Coming Soon'}
        </Badge>
      </div>
      
      <CardHeader>
        <div className="flex justify-between items-start">
          <CardTitle className="text-xl">{event.title}</CardTitle>
        </div>
        <CardDescription className="line-clamp-2">{event.description}</CardDescription>
      </CardHeader>
      
      <CardContent className="flex-grow">
        <div className="space-y-3 text-sm">
          <div className="flex items-center text-muted-foreground">
            <Calendar className="mr-2 h-4 w-4" />
            <span>{dateRange}</span>
          </div>
          
          <div className="flex items-center text-muted-foreground">
            <Clock className="mr-2 h-4 w-4" />
            <span>{daysRemaining} {daysRemaining === 1 ? 'day' : 'days'} remaining</span>
          </div>
          
          <div className="mt-4">
            <p className="text-sm font-medium mb-2">Memory Theme:</p>
            <p className="text-sm text-muted-foreground line-clamp-3">{event.memoryDescription}</p>
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="border-t bg-muted/10 pt-4">
        <Button className="w-full" variant="default" asChild>
          <Link href={`/events/${event.id}`}>
            View Event Details
            <ChevronRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ThemedEvents;