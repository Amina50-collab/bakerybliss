import { Link } from "wouter";
import Hero from "@/components/Hero";
import ProcessFlow from "@/components/ProcessFlow";
import BakingZones from "@/components/BakingZones";
import RecipeCard from "@/components/RecipeCard";
import Gallery from "@/components/Gallery";
import Testimonials from "@/components/Testimonials";
import Newsletter from "@/components/Newsletter";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet";
import { CalendarDays, ChevronRight, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import type { Event } from '@shared/schema';

const Home = () => {
  const { data: recipes } = useQuery({
    queryKey: ['/api/recipes'],
  });

  const { data: activeEvents } = useQuery<Event[]>({
    queryKey: ['/api/events/active'],
  });

  return (
    <>
      <Helmet>
        <title>Childhood Bakery Café | Turn your childhood into reality</title>
        <meta name="description" content="Create customized baked goods in our interactive cafe experience. Turn your childhood dreams into reality with our four distinct baking zones." />
      </Helmet>
      
      <Hero />
      <ProcessFlow />
      <BakingZones />
      
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="font-pacifico text-4xl text-center text-[#8B4513] mb-4">Nostalgic Favorites</h2>
          <p className="text-center text-gray-700 mb-12 max-w-2xl mx-auto">
            Recreate these childhood classics or use them as inspiration for your own creations.
          </p>
          
          {recipes && recipes.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {Array.isArray(recipes) && recipes.slice(0, 4).map((recipe: any, index: number) => (
                <RecipeCard key={recipe.id} recipe={recipe} index={index} />
              ))}
            </div>
          ) : (
            <div className="flex justify-center p-8">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#8B4513]"></div>
            </div>
          )}
        </div>
      </section>
      
      {/* Themed Events Section */}
      <section className="py-16 bg-[#FFF8E1]">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between mb-12">
            <div className="mb-6 md:mb-0">
              <h2 className="font-pacifico text-4xl text-[#8B4513] mb-4">Childhood Memory Events</h2>
              <p className="text-gray-700 max-w-2xl">
                Join our special events inspired by cherished childhood memories. Create treats that bring back the magic of your favorite childhood moments!
              </p>
            </div>
            <Button asChild className="px-6 py-6" size="lg">
              <Link href="/events">
                View All Events
                <ChevronRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
          
          {activeEvents && activeEvents.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {Array.isArray(activeEvents) && activeEvents.slice(0, 3).map((event: any) => (
                <ThemedEventCard key={event.id} event={event} />
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-lg p-8 text-center shadow-sm">
              <CalendarDays className="mx-auto h-12 w-12 text-[#8B4513] mb-4 opacity-50" />
              <h3 className="text-xl font-semibold mb-2">No Active Events</h3>
              <p className="text-gray-600 mb-6">Check back soon for upcoming themed events!</p>
              <Button variant="outline" asChild>
                <Link href="/create">Create Your Own Treat</Link>
              </Button>
            </div>
          )}
        </div>
      </section>
      
      <Gallery />
      <Testimonials />
      <Newsletter />
    </>
  );
};

// Themed Event Card Component
interface ThemedEventCardProps {
  event: Event;
}

const ThemedEventCard = ({ event }: ThemedEventCardProps) => {
  // Format dates for display
  const startDate = new Date(event.startDate);
  const endDate = new Date(event.endDate);
  
  // Calculate days remaining
  const daysRemaining = Math.ceil((endDate.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
  
  return (
    <Card className="overflow-hidden h-full flex flex-col shadow-sm hover:shadow-md transition-shadow">
      <div className="aspect-video bg-muted relative overflow-hidden">
        {event.imageUrl ? (
          <img 
            src={event.imageUrl} 
            alt={event.title} 
            className="object-cover w-full h-full"
          />
        ) : (
          <div className="flex items-center justify-center h-full bg-gradient-to-r from-amber-100 to-amber-200">
            <Star className="h-12 w-12 text-amber-500 mb-2" />
            <span className="text-2xl font-bold text-amber-700">{event.theme}</span>
          </div>
        )}
        <Badge className="absolute top-3 right-3 bg-amber-600">
          {daysRemaining} days left
        </Badge>
      </div>
      
      <CardHeader>
        <CardTitle className="text-xl line-clamp-1">{event.title}</CardTitle>
        <CardDescription className="line-clamp-2">
          {event.description}
        </CardDescription>
      </CardHeader>
      
      <CardContent className="flex-grow">
        <div className="flex items-center text-sm text-muted-foreground mb-3">
          <CalendarDays className="mr-2 h-4 w-4" />
          <span>{format(startDate, 'MMM d')} - {format(endDate, 'MMM d, yyyy')}</span>
        </div>
        <p className="text-sm line-clamp-3">{event.memoryDescription}</p>
      </CardContent>
      
      <CardFooter className="pt-0">
        <Button className="w-full" variant="outline" asChild>
          <Link href={`/events/${event.id}`}>
            View Event Details
          </Link>
        </Button>
      </CardFooter>
    </Card>
  );
};

export default Home;
