import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CardHover } from "@/components/ui/card-hover";
import { RecipeCard } from "@/components/ui/recipe-card";
import { areas, featuredItems, testimonials } from "@/lib/utils";

export default function HomePage() {
  return (
    <div className="container mx-auto">
      {/* Welcome Section */}
      <section className="mb-10">
        <div className="relative rounded-2xl overflow-hidden h-64 md:h-96">
          <img 
            src="https://images.unsplash.com/photo-1445116572660-236099ec97a0?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=600&q=80" 
            alt="Warm cafe interior with baking stations" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-darkbrown/70 to-darkbrown/30 flex items-center">
            <div className="px-6 md:px-12 w-full md:w-3/5">
              <h2 className="font-display text-3xl md:text-5xl text-white mb-4">Welcome to BakeJoy!</h2>
              <p className="text-white text-lg mb-6">Create your own delicious bakery treats across our four exciting zones!</p>
              <Link href="/grocery">
                <Button className="bg-primary hover:bg-primary/90 text-white py-2 px-6 rounded-full font-bold transition-colors">
                  Start Baking
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Cafe Areas */}
      <section className="mb-16">
        <h2 className="font-display text-3xl text-darkbrown text-center mb-10">Our Baking Zones</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {areas.map((area) => (
            <CardHover
              key={area.id}
              title={area.name}
              description={area.description}
              image={area.image}
              color={area.color}
              buttonText={area.buttonText}
              href={area.route}
              step={area.step}
            />
          ))}
        </div>
      </section>

      {/* Featured Creations */}
      <section className="mb-16">
        <h2 className="font-display text-3xl text-darkbrown text-center mb-10">Childhood Favorites</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredItems.map((item) => (
            <RecipeCard
              key={item.id}
              title={item.name}
              description={item.description}
              image={item.image}
              recipeId={item.id}
            />
          ))}
        </div>
      </section>

      {/* Testimonials */}
      <section>
        <h2 className="font-display text-3xl text-darkbrown text-center mb-10">Happy Bakers</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="bg-white p-6 rounded-xl shadow-md">
              <CardContent className="p-0">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mr-3">
                    <i className="fas fa-user text-primary"></i>
                  </div>
                  <div>
                    <h3 className="font-bold">{testimonial.name}</h3>
                    <div className="flex text-accent">
                      {Array.from({ length: Math.floor(testimonial.rating) }).map((_, i) => (
                        <i key={i} className="fas fa-star"></i>
                      ))}
                      {testimonial.rating % 1 !== 0 && (
                        <i className="fas fa-star-half-alt"></i>
                      )}
                    </div>
                  </div>
                </div>
                <p className="text-gray-600 italic">"{testimonial.text}"</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    </div>
  );
}
