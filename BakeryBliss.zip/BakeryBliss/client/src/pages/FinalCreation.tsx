import { useEffect } from "react";
import { useLocation, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useBakingFlow } from "@/hooks/use-baking-flow";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function FinalCreation() {
  const [, navigate] = useLocation();
  const { 
    selectedRecipe, 
    selectedFrosting,
    selectedFrostingStyle,
    selectedToppings,
    customMessage,
    selectedFont,
    reset
  } = useBakingFlow();
  
  const { toast } = useToast();
  
  const { data: frostings } = useQuery({ queryKey: ['/api/frostings'] });
  const { data: decorations } = useQuery({ queryKey: ['/api/decorations'] });
  const { data: recipes } = useQuery({ 
    queryKey: ['/api/recipes'],
  });
  
  useEffect(() => {
    // Redirect if creation process wasn't completed
    if (!selectedRecipe || !selectedFrosting) {
      navigate("/grocery");
      toast({
        title: "Incomplete creation",
        description: "Please complete all steps to view your final creation",
        variant: "destructive"
      });
    }
  }, [selectedRecipe, selectedFrosting, navigate, toast]);

  const handleSave = async () => {
    try {
      // Format creation data
      const bakedItem = {
        name: customMessage || "My Custom Creation",
        type: selectedRecipe || "cake",
        userId: 1, // Default user ID
        ingredients: ["flour", "sugar", "eggs"], // Default ingredients
        frosting: selectedFrosting,
        decoration: selectedToppings,
        imageUrl: "https://images.unsplash.com/photo-1578985545062-69928b1d9587"
      };
      
      // Save to database
      await apiRequest('/api/baked-items', 'POST', bakedItem);
      
      toast({
        title: "Creation Saved!",
        description: "Your delicious creation has been saved to the gallery.",
      });
      
      // Reset the creation flow
      reset();
      
      // Navigate to homepage after a brief delay
      setTimeout(() => {
        navigate("/");
      }, 2000);
      
    } catch (error) {
      toast({
        title: "Error saving creation",
        description: "There was a problem saving your creation. Please try again.",
        variant: "destructive"
      });
      console.error(error);
    }
  };

  // Find details of selected recipe, frosting, etc.
  const recipe = recipes?.find(r => r.id.toString() === selectedRecipe);
  const frosting = frostings?.find(f => f.id.toString() === selectedFrosting);
  
  return (
    <div className="container mx-auto py-8">
      <h1 className="font-pacifico text-4xl text-center text-[#8B4513] mb-4">Your Creation is Complete!</h1>
      <p className="text-center text-gray-600 mb-12 max-w-2xl mx-auto">
        Congratulations! You've completed all steps and created a delicious treat.
      </p>
      
      <div className="max-w-4xl mx-auto">
        <Card className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="md:flex">
            <div className="md:w-1/2">
              <div className="h-80 bg-[#FFF8E1] flex items-center justify-center p-4">
                <div className="w-64 h-64 rounded-full bg-yellow-100 relative flex items-center justify-center">
                  {/* Frosting color */}
                  <div 
                    className="absolute inset-0 rounded-full" 
                    style={{ 
                      backgroundColor: frosting?.color || "#FFF",
                      opacity: 0.8
                    }}
                  ></div>
                  
                  {/* Toppings */}
                  {selectedToppings.length > 0 && (
                    <div className="absolute inset-0 flex flex-wrap justify-center items-center p-4 z-10">
                      {selectedToppings.map((id) => {
                        const decoration = decorations?.find(d => d.id.toString() === id);
                        return (
                          <span key={id} className="m-1 text-xs px-2 py-1 bg-white rounded-full shadow-sm">
                            {decoration?.name || id}
                          </span>
                        );
                      })}
                    </div>
                  )}
                  
                  {/* Message */}
                  {customMessage && (
                    <div className={`absolute bottom-0 left-0 right-0 text-center p-2 bg-white bg-opacity-80 z-20 ${
                      selectedFont === 'script' ? 'font-pacifico' : 
                      selectedFont === 'block' ? 'font-bold uppercase' :
                      selectedFont === 'fun' ? 'font-bold text-[#6A5ACD]' :
                      'font-serif'
                    }`}>
                      {customMessage}
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            <div className="md:w-1/2 p-6">
              <div className="mb-6">
                <h2 className="font-bold text-2xl text-[#8B4513] mb-2">
                  {customMessage || "My Custom Creation"}
                </h2>
                <p className="text-gray-600 italic">
                  Created with love at Childhood Bakery Café
                </p>
              </div>
              
              <div className="space-y-4 mb-8">
                <div>
                  <h3 className="font-bold text-[#FFD700]">Base</h3>
                  <p>{recipe?.name || "Custom Recipe"}</p>
                </div>
                
                <div>
                  <h3 className="font-bold text-[#FFB6C1]">Frosting</h3>
                  <div className="flex items-center">
                    <div 
                      className="w-4 h-4 rounded-full mr-2" 
                      style={{ backgroundColor: frosting?.color || "#FFF" }}
                    ></div>
                    <span>{frosting?.name || "Custom Frosting"}</span>
                    {selectedFrostingStyle && (
                      <span className="text-sm text-gray-500 ml-2">
                        ({selectedFrostingStyle} style)
                      </span>
                    )}
                  </div>
                </div>
                
                <div>
                  <h3 className="font-bold text-[#6A5ACD]">Decorations</h3>
                  {selectedToppings.length > 0 ? (
                    <ul className="list-disc pl-5">
                      {selectedToppings.map((id) => {
                        const decoration = decorations?.find(d => d.id.toString() === id);
                        return (
                          <li key={id}>
                            {decoration?.name || id}
                          </li>
                        );
                      })}
                    </ul>
                  ) : (
                    <p className="text-gray-500">No decorations added</p>
                  )}
                </div>
              </div>
              
              <div className="flex space-x-4">
                <Button 
                  onClick={handleSave}
                  className="bg-[#8B4513] hover:bg-[#8B4513]/90 text-white flex-1"
                >
                  Save to Gallery
                </Button>
                
                <Link href="/">
                  <Button 
                    variant="outline" 
                    className="border-[#8B4513] text-[#8B4513] flex-1"
                    onClick={reset}
                  >
                    Start Over
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </Card>
        
        <div className="mt-10 text-center">
          <h3 className="font-pacifico text-2xl text-[#8B4513] mb-4">Share Your Creation</h3>
          <div className="flex justify-center space-x-4">
            <Button variant="outline" className="border-[#4267B2] text-[#4267B2]">
              <i className="ri-facebook-fill mr-2"></i> Share
            </Button>
            <Button variant="outline" className="border-[#1DA1F2] text-[#1DA1F2]">
              <i className="ri-twitter-fill mr-2"></i> Tweet
            </Button>
            <Button variant="outline" className="border-[#E60023] text-[#E60023]">
              <i className="ri-pinterest-fill mr-2"></i> Pin
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}