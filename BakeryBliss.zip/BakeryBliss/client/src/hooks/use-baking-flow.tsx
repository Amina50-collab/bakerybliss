import React, { createContext, useContext, useState, type ReactNode } from "react";

interface BakingFlowContextType {
  selectedRecipe: string | null;
  setSelectedRecipe: (recipeId: string) => void;
  currentStep: number;
  setCurrentStep: (step: number) => void;
  selectedFrosting: string | null;
  setSelectedFrosting: (frostingId: string) => void;
  selectedFrostingStyle: string | null;
  setSelectedFrostingStyle: (styleId: string) => void;
  selectedToppings: string[];
  setSelectedToppings: (toppings: string[]) => void;
  selectedDesign: string | null;
  setSelectedDesign: (designId: string) => void;
  customMessage: string;
  setCustomMessage: (message: string) => void;
  selectedFont: string;
  setSelectedFont: (font: string) => void;
  reset: () => void;
}

const defaultContext: BakingFlowContextType = {
  selectedRecipe: null,
  setSelectedRecipe: () => {},
  currentStep: 1,
  setCurrentStep: () => {},
  selectedFrosting: null,
  setSelectedFrosting: () => {},
  selectedFrostingStyle: null,
  setSelectedFrostingStyle: () => {},
  selectedToppings: [],
  setSelectedToppings: () => {},
  selectedDesign: null,
  setSelectedDesign: () => {},
  customMessage: "",
  setCustomMessage: () => {},
  selectedFont: "script",
  setSelectedFont: () => {},
  reset: () => {},
};

const BakingFlowContext = createContext<BakingFlowContextType>(defaultContext);

interface BakingFlowProviderProps {
  children: ReactNode;
}

export function BakingFlowProvider({ children }: BakingFlowProviderProps): JSX.Element {
  const [selectedRecipe, setSelectedRecipe] = useState<string | null>(null);
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedFrosting, setSelectedFrosting] = useState<string | null>(null);
  const [selectedFrostingStyle, setSelectedFrostingStyle] = useState<string | null>(null);
  const [selectedToppings, setSelectedToppings] = useState<string[]>([]);
  const [selectedDesign, setSelectedDesign] = useState<string | null>(null);
  const [customMessage, setCustomMessage] = useState("");
  const [selectedFont, setSelectedFont] = useState("script");

  const reset = () => {
    setSelectedRecipe(null);
    setCurrentStep(1);
    setSelectedFrosting(null);
    setSelectedFrostingStyle(null);
    setSelectedToppings([]);
    setSelectedDesign(null);
    setCustomMessage("");
    setSelectedFont("script");
  };

  const contextValue: BakingFlowContextType = {
    selectedRecipe,
    setSelectedRecipe,
    currentStep,
    setCurrentStep,
    selectedFrosting,
    setSelectedFrosting,
    selectedFrostingStyle,
    setSelectedFrostingStyle,
    selectedToppings,
    setSelectedToppings,
    selectedDesign,
    setSelectedDesign,
    customMessage,
    setCustomMessage,
    selectedFont,
    setSelectedFont,
    reset
  };

  return (
    <BakingFlowContext.Provider value={contextValue}>
      {children}
    </BakingFlowContext.Provider>
  );
}

export function useBakingFlow(): BakingFlowContextType {
  const context = useContext(BakingFlowContext);
  if (!context) {
    throw new Error("useBakingFlow must be used within a BakingFlowProvider");
  }
  return context;
}