import { createContext, useContext, useState, ReactNode } from 'react';

interface BakeryContextType {
  basket: string[];
  currentZone: number;
  addToBasket: (item: string) => void;
  removeFromBasket: (item: string) => void;
  clearBasket: () => void;
  setCurrentZone: (zone: number) => void;
}

const BakeryContext = createContext<BakeryContextType | undefined>(undefined);

export const BakeryProvider = ({ children }: { children: ReactNode }) => {
  const [basket, setBasket] = useState<string[]>([]);
  const [currentZone, setCurrentZone] = useState<number>(1);

  const addToBasket = (item: string) => {
    if (!basket.includes(item)) {
      setBasket([...basket, item]);
    }
  };

  const removeFromBasket = (item: string) => {
    setBasket(basket.filter(i => i !== item));
  };

  const clearBasket = () => {
    setBasket([]);
  };

  return (
    <BakeryContext.Provider 
      value={{ 
        basket, 
        currentZone,
        addToBasket, 
        removeFromBasket, 
        clearBasket,
        setCurrentZone
      }}
    >
      {children}
    </BakeryContext.Provider>
  );
};

export const useBakery = () => {
  const context = useContext(BakeryContext);
  if (context === undefined) {
    throw new Error('useBakery must be used within a BakeryProvider');
  }
  return context;
};
